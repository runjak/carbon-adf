// 
// Copyright (c) 2006-2012, Benjamin Kaufmann
// 
// This file is part of Clasp. See http://www.cs.uni-potsdam.de/clasp/ 
// 
// Clasp is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// Clasp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Clasp; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//
#include <clasp/solve_algorithms.h>
#include <clasp/solver.h>
#include <clasp/enumerator.h>
#include <clasp/util/timer.h>
#include <cmath>
namespace Clasp { 
ProgressReport::ProgressReport()  {}
ProgressReport::~ProgressReport() {}
/////////////////////////////////////////////////////////////////////////////////////////
// SolveParams
/////////////////////////////////////////////////////////////////////////////////////////
SolveParams::SolveParams() 
	: randProb(0.0f) {
}
ContextOptions::ContextOptions() {
	std::memset(this, 0, sizeof(ContextOptions));
}
/////////////////////////////////////////////////////////////////////////////////////////
// RestartParams
/////////////////////////////////////////////////////////////////////////////////////////
void RestartParams::disable() {
	sched         = ScheduleStrategy::none();
	std::memset(&counterRestart, 0, sizeof(uint64));
}
uint32 SumQueue::restart(uint32 maxLBD, float limMax) {
	++nRestart;
	if (upCfl >= upForce) {
		double avg = upCfl / double(nRestart);
		double gLbd= globalAvgLbd();
		bool   sx  = samples >= upForce;
		upCfl      = 0;
		nRestart   = 0;
		if      (avg >= 16000.0) { lim += 0.1f;  upForce = 16000; }
		else if (sx)             { lim += 0.05f; upForce = std::max(uint32(16000), upForce-10000); }
		else if (avg >= 4000.0)  { lim += 0.05f; }
		else if (avg >= 1000.0)  { upForce += 10000u; }
		else if (lim > limMax)   { lim -= 0.05f; }
		if ((gLbd > maxLBD)==lbd){ dynamicRestarts(limMax, !lbd); }
	}
	resetQueue();
	return upForce;
}
/////////////////////////////////////////////////////////////////////////////////////////
// ReduceParams
/////////////////////////////////////////////////////////////////////////////////////////
uint32 ReduceParams::getLimit(uint32 base, double f, const Range32& r) {
	base = (f != 0.0 ? (uint32)std::min(base*f, double(UINT32_MAX)) : UINT32_MAX);
	return r.clamp( base );
}
uint32 ReduceParams::getBase(const SharedContext& ctx) const {
	return strategy.estimate ? ctx.stats().complexity : ctx.stats().size; 
}
void ReduceParams::disable() {
	cflSched  = ScheduleStrategy::none();
	growSched = ScheduleStrategy::none();
	strategy.scheds  = 0;
	strategy.fReduce = 0;
	fGrow     = 0.0f; fInit = 0.0f; fMax = 0.0f;
	initRange = Range<uint32>(UINT32_MAX, UINT32_MAX); 
	maxRange  = UINT32_MAX;
}
Range32 ReduceParams::sizeLimits(const SharedContext& ctx) const {
	if (!growSched.disabled() || growSched.defaulted()) {
		return Range32(initLimit(ctx), maxLimit(ctx));
	}
	return Range32(maxRange, maxRange);
}
uint32 ReduceParams::cflInit(const SharedContext& ctx) const {
	return cflSched.disabled() ? 0 : initLimit(ctx);
}
/////////////////////////////////////////////////////////////////////////////////////////
// InitParams
/////////////////////////////////////////////////////////////////////////////////////////
bool InitParams::randomize(Solver& s) const {
	for (uint32 i = 0, j = randConf; i != randRuns && j; ++i) {
		if (s.search(j, UINT32_MAX, false, 1.0) != value_free) { return !s.hasConflict(); }
		s.undoUntil(0);
	}
	return true;
}
/////////////////////////////////////////////////////////////////////////////////////////
// Schedule
/////////////////////////////////////////////////////////////////////////////////////////
double growR(uint32 idx, double g)       { return pow(g, (double)idx); }
double addR(uint32 idx, double a)        { return a * idx; }
uint32 lubyR(uint32 idx)                 {
	uint32 i = idx + 1;
	while ((i & (i+1)) != 0) {
		i    -= ((1u << log2(i)) - 1);
	}
	return (i+1)>>1;
}
ScheduleStrategy::ScheduleStrategy(Type t, uint32 b, double up, uint32 lim)
	: base(b), type(t), idx(0), len(lim), grow(0.0)  {
	if      (t == geometric_schedule)  { grow = static_cast<float>(std::max(1.0, up)); }
	else if (t == arithmetic_schedule) { grow = static_cast<float>(std::max(0.0, up)); }
	else if (t == user_schedule)       { grow = static_cast<float>(std::max(0.0, up)); }
	else if (t == luby_schedule && lim){ len  = std::max(uint32(2), (static_cast<uint32>(std::pow(2.0, std::ceil(log(double(lim))/log(2.0)))) - 1)*2); }
}

uint64 ScheduleStrategy::current() const {
	enum { t_add = ScheduleStrategy::arithmetic_schedule, t_luby = ScheduleStrategy::luby_schedule };
	if      (base == 0)     return UINT64_MAX;
	else if (type == t_add) return static_cast<uint64>(addR(idx, grow)  + base);
	else if (type == t_luby)return static_cast<uint64>(lubyR(idx)) * base;
	uint64 x = static_cast<uint64>(growR(idx, grow) * base);
	return x + !x;
}
uint64 ScheduleStrategy::next() {
	if (++idx != len) { return current(); }
	// length reached or overflow
	len = (len + !!idx) << uint32(type == luby_schedule);
	idx = 0;
	return current();
}
void ScheduleStrategy::advanceTo(uint32 n) {
	if (!len || n < len)       { 
		idx = n; 
		return; 
	}
	if (type != luby_schedule) {
		double dLen = len;
		uint32 x    = uint32(sqrt(dLen * (4.0 * dLen - 4.0) + 8.0 * double(n+1))-2*dLen+1)/2;
    idx         = n - uint32(x*dLen+double(x-1.0)*x/2.0);
    len        += x;
		return;
	}
	while (n >= len) {
		n   -= len++;
		len *= 2;
	}
	idx = n;
}
/////////////////////////////////////////////////////////////////////////////////////////
// Basic solve
/////////////////////////////////////////////////////////////////////////////////////////
struct BasicSolve::State {
	typedef SolvePathEvent EventType;
	State(Solver& s, const SolveParams& p);
	ValueRep solve(Solver& s, const SolveParams& p, SolveLimits* lim);
	uint64           dbGrowNext;
	double           dbMax;
	ScheduleStrategy dbRed;
	uint32           nRestart;
	uint32           nGrow;
	uint32           dbRedInit;
	uint32           dbPinned;
	uint32           rsShuffle;
};

BasicSolve::BasicSolve(Solver& s, const SolveParams& p, SolveLimits* lim) 
	: solver_(&s)
	, params_(&p)
	, limits_(lim)
	, state_(0) {
}
BasicSolve::~BasicSolve(){ reset(); }
void BasicSolve::reset(bool reinit) { 
	if (!state_ || reinit) {
		delete state_;
		state_ = 0;
	}
	else {
		state_->~State();
		new (state_) State(*solver_, *params_); 
	}
}
void BasicSolve::reset(Solver& s, const SolveParams& p, SolveLimits* lim) { 
	solver_ = &s; 
	params_ = &p; 
	limits_ = lim;
	reset(true); 
}

ValueRep BasicSolve::solve() {
	if (limits_ && limits_->reached())                { return value_free;  }
	if (!state_ && !params_->init.randomize(*solver_)){ return value_false; }
	if (!state_)                                      { state_ = new State(*solver_, *params_); }
	return state_->solve(*solver_, *params_, limits_);
}

bool BasicSolve::satisfiable(const LitVec& path, bool init) {
	if (!solver_->clearAssumptions() || !solver_->pushRoot(path)) { return false; }
	if (init && !params_->init.randomize(*solver_))               { return false; }
	State temp(*solver_, *params_);
	return temp.solve(*solver_, *params_, 0) == value_true;
}

bool BasicSolve::assume(const LitVec& path) {
	return solver_->pushRoot(path);
}

BasicSolve::State::State(Solver& s, const SolveParams& p) {
	Range32 dbLim= p.reduce.sizeLimits(*s.sharedContext());
	dbGrowNext   = p.reduce.growSched.current();
	dbMax        = dbLim.lo;
	dbRed        = p.reduce.cflSched;
	nRestart     = 0;
	nGrow        = 0;
	dbRedInit    = p.reduce.cflInit(*s.sharedContext());
	dbPinned     = 0;
	rsShuffle    = p.restart.shuffle;
	if (dbLim.lo < s.numLearntConstraints()) { 
		dbMax      = std::min((double)dbLim.hi, double(s.numLearntConstraints() + p.reduce.initRange.lo));
	}
	if (dbRedInit && dbRed.type != ScheduleStrategy::luby_schedule) {
		if (dbRedInit < dbRed.base) {
			dbRedInit  = std::min(dbRed.base, std::max(dbRedInit,(uint32)5000));
			dbRed.grow = dbRedInit != dbRed.base ? std::min(dbRed.grow, dbRedInit/2.0f) : dbRed.grow;
			dbRed.base = dbRedInit;
		}
		dbRedInit = 0;
	}
	if (p.restart.dynamic()) {
		s.stats.enableQueue(p.restart.sched.base);
		s.stats.queue->resetGlobal();
		s.stats.queue->dynamicRestarts((float)p.restart.sched.grow, true);
	}
	s.stats.cflLast = s.stats.analyzed;
}

ValueRep BasicSolve::State::solve(Solver& s, const SolveParams& p, SolveLimits* lim) {
	assert(!lim || !lim->reached());
	struct ConflictLimits {
		uint64 restart; // current restart limit
		uint64 reduce;  // current reduce limit
		uint64 grow;    // current limit for next growth operation
		uint64 global;  // current global limit
		uint64 min()      const { return std::min(std::min(restart, grow), std::min(reduce, global)); }
		void  update(uint64 x)  { restart -= x; reduce -= x; grow -= x; global -= x; }
	};
	WeightLitVec inDegree;
	SearchLimits sLimit;
	ScheduleStrategy rs     = p.restart.sched;
	ScheduleStrategy dbGrow = p.reduce.growSched;
	Solver::DBInfo  db      = {0,0,dbPinned};
	double          dbHigh  = p.reduce.sizeLimits(*s.sharedContext()).hi;
	ValueRep result         = value_free;
	ConflictLimits cLimit   = {UINT64_MAX, dbRed.current() + dbRedInit, dbGrowNext, lim ? lim->conflicts : UINT64_MAX};
	uint64  limRestarts     = lim ? lim->restarts : UINT64_MAX;
	uint64& rsLimit         = p.restart.local() ? sLimit.local : cLimit.restart;
	if (!dbGrow.disabled())  { dbGrow.advanceTo(nGrow); }
	if (nRestart == UINT32_MAX && p.restart.update() == RestartParams::seq_disable) {
		cLimit.restart  = UINT64_MAX;
		sLimit          = SearchLimits();
	}
	else if (p.restart.dynamic()) {
		if (!nRestart) { s.stats.queue->resetQueue(); s.stats.queue->dynamicRestarts((float)p.restart.sched.grow, true); }
		sLimit.dynamic  = s.stats.queue; 
		rsLimit         = sLimit.dynamic->upForce - std::min(sLimit.dynamic->samples, sLimit.dynamic->upForce - 1);
	}
	else {
		rs.advanceTo(!rs.disabled() ? nRestart : 0);
		rsLimit         = rs.current();
	}
	for (EventType progress(s, SolvePathEvent::event_restart, 0, 0); cLimit.global; ) {
		uint64 minLimit = cLimit.min(); assert(minLimit);
		sLimit.learnts  = (uint32)std::min(dbMax + (db.pinned*p.reduce.strategy.noGlue), dbHigh);
		sLimit.conflicts= minLimit;
		progress.cLimit = std::min(minLimit, sLimit.local);
		progress.lLimit = sLimit.learnts;
		if (progress.evType) { s.sharedContext()->reportProgress(progress); progress.evType = SolvePathEvent::event_none; }
		result          = s.search(sLimit, p.randProb);
		minLimit       -= sLimit.conflicts; // number of conflicts in this iteration
		if (result != value_free) {
			progress.evType = result == value_true ? SolvePathEvent::event_model : SolvePathEvent::event_unsat;
			if (result == value_true && p.restart.update() != RestartParams::seq_continue) { 
				if      (p.restart.update() == RestartParams::seq_repeat) { nRestart = 0; }
				else if (p.restart.update() == RestartParams::seq_disable){ nRestart = UINT32_MAX; }
			}
			if (!dbGrow.disabled()) { dbGrowNext = std::max(cLimit.grow - minLimit, uint64(1)); }
			s.sharedContext()->reportProgress(progress);
			break;
		}
		cLimit.update(minLimit);
		minLimit = 0;
		if (rsLimit == 0 || sLimit.hasDynamicRestart()) {
			// restart reached - do restart
			++nRestart;
			if (p.restart.counterRestart && (nRestart % p.restart.counterRestart) == 0 ) {
				inDegree.clear();
				s.heuristic()->bump(s, inDegree, p.restart.counterBump / (double)s.inDegree(inDegree));
			}
			if (sLimit.dynamic) {
				minLimit = sLimit.dynamic->samples;
				rsLimit  = sLimit.dynamic->restart(rs.len ? rs.len : UINT32_MAX, (float)rs.grow);
			}
			s.restart();
			if (rsLimit == 0)              { rsLimit   = rs.next(); }
			if (!minLimit)                 { minLimit  = rs.current(); }
			if (p.reduce.strategy.fRestart){ db        = s.reduceLearnts(p.reduce.fRestart(), p.reduce.strategy); }
			if (nRestart == rsShuffle)     { rsShuffle+= p.restart.shuffleNext; s.shuffleOnNextSimplify();}
			if (--limRestarts == 0)        { break; }
			s.stats.cflLast = s.stats.analyzed;
			progress.evType = SolvePathEvent::event_restart;
		}
		if (cLimit.reduce == 0 || s.learntLimit(sLimit)) {
			// reduction reached - remove learnt constraints
			db              = s.reduceLearnts(p.reduce.fReduce(), p.reduce.strategy);
			cLimit.reduce   = dbRedInit + (cLimit.reduce == 0 ? dbRed.next() : dbRed.current());
			progress.evType = std::max(progress.evType, SolvePathEvent::event_deletion);
			if (s.learntLimit(sLimit) || db.pinned >= dbMax) { 
				ReduceStrategy t; t.algo = 2; t.score = 2; t.glue = 0;
				db.pinned /= 2;
				db.size    = s.reduceLearnts(0.5f, t).size;
				if (db.size >= sLimit.learnts) { dbMax = std::min(dbMax + std::max(100.0, s.numLearntConstraints()/10.0), dbHigh); }
			}
		}
		if (cLimit.grow == 0 || (dbGrow.defaulted() && progress.evType == SolvePathEvent::event_restart)) {
			// grow sched reached - increase max db size
			if (cLimit.grow == 0)                             { cLimit.grow = dbGrow.next(); minLimit = cLimit.grow; ++nGrow; }
			if ((s.numLearntConstraints() + minLimit) > dbMax){ dbMax  *= p.reduce.fGrow; progress.evType = std::max(progress.evType, SolvePathEvent::event_grow); }
			if (dbMax > dbHigh)                               { dbMax   = dbHigh; cLimit.grow = UINT64_MAX; dbGrow = ScheduleStrategy::none(); }
		}
	}
	dbPinned        = db.pinned;
	s.stats.cflLast = s.stats.analyzed - s.stats.cflLast;
	if (lim) {
		if (lim->conflicts != UINT64_MAX) { lim->conflicts = cLimit.global; }
		if (lim->restarts  != UINT64_MAX) { lim->restarts  = limRestarts;   }
	}
	return result;
}
/////////////////////////////////////////////////////////////////////////////////////////
// SolveAlgorithm
/////////////////////////////////////////////////////////////////////////////////////////
SolveAlgorithm::SolveAlgorithm(Enumerator* e, const SolveLimits& lim) : limits_(lim), enum_(e)  {
	if (!e) { enum_ = &NullEnumerator::instance(); }
}
SolveAlgorithm::~SolveAlgorithm() {}

bool SolveAlgorithm::beginSolve(SharedContext& ctx) { 
	ctx.solve = this;
	return ctx.frozen() || ctx.endInit();
}
bool SolveAlgorithm::endSolve(SharedContext& ctx, bool more) {
	enum_->reportResult(!more);
	ctx.solve = 0;
	return more;
}

bool SolveAlgorithm::solve(SharedContext& ctx, const LitVec& assume) {
	if (!beginSolve(ctx)) { return endSolve(ctx, false); }
	bool more = limits_.conflicts == 0 || doSolve(ctx, assume);
	return endSolve(ctx, more);
}

bool SolveAlgorithm::doSolve(SharedContext& ctx, const LitVec& path) {
	Solver&     s    = *ctx.master();
	SolveLimits lim  = solveLimits();
	uint32 root      = s.rootLevel();
	bool   complete  = true;
	Timer<RealTime> tt; tt.start();
	ctx.reportProgress(SolveStateEvent(s, "algorithm"));
	ctx.accuStats(s.stats);
	s.stats.reset();
	BasicSolve solve(s, ctx.configuration()->search(0), &lim);
	ValueRep   res;
	for (bool hasWork= ctx.attach(s); hasWork; solve.reset()) {
		// Add assumptions - if this fails, the problem is unsat 
		// under the current assumptions but not necessarily unsat.
		if (solve.assume(path)) {
			do {
				res = solve.solve();
			} while (res == value_true && enumerator().backtrackFromModel(s) == Enumerator::enumerate_continue && enumerator().continueFromModel(s));
			complete = res != value_free && s.decisionLevel() == s.rootLevel();
		}
		// finished current work item
		hasWork    = complete && enumerator().backtrackFromUnsat(s, true) == Enumerator::enumerate_continue;
		if (!s.popRootLevel(s.rootLevel() - root) || !s.propagate() || !s.simplify()) {
			hasWork  = false;
		}
	}
	setSolveLimits(lim);
	ctx.detach(s);
	tt.stop();
	ctx.reportProgress(SolveStateEvent(s, "algorithm", tt.total()));
	return !complete;
}

}
