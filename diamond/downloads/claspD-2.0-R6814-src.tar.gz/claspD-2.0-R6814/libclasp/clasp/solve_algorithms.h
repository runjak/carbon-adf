// 
// Copyright (c) 2006-2012, Benjamin Kaufmann
// 
// This file is part of Clasp. See http://www.cs.uni-potsdam.de/clasp/ 
// 
// Clasp is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// Clasp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Clasp; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//
#ifndef CLASP_SOLVE_ALGORITHMS_H_INCLUDED
#define CLASP_SOLVE_ALGORITHMS_H_INCLUDED

#ifdef _MSC_VER
#pragma warning (disable : 4200) // nonstandard extension used : zero-sized array
#pragma once
#endif

#include <clasp/solver_strategies.h>
/*!
 * \file 
 * Defines top-level functions for solving problems.
 */
namespace Clasp {

//! Type for holding global solve limits.
struct SolveLimits {
	explicit SolveLimits(uint64 conf = UINT64_MAX, uint64 r = UINT64_MAX) 
		: conflicts(conf)
		, restarts(r) {
	}
	bool   reached() const { return conflicts == 0 || restarts == 0; }
	uint64 conflicts; /*!< Number of conflicts. */
	uint64 restarts;  /*!< Number of restarts.  */
};

///////////////////////////////////////////////////////////////////////////////
// Basic solving
///////////////////////////////////////////////////////////////////////////////
//! Basic (sequential) solving using given solving options.
class BasicSolve {
public:
	//! Creates a new object for solving with the given solver using the given solving options.
	/*!
	 * \pre s is attached to a problem (SharedContext).
	 * \param lim   Solving limits to apply (in/out parameter).
	 */
	BasicSolve(Solver& s, const SolveParams& p, SolveLimits* lim = 0);
	~BasicSolve();
	
	//! Enables solving under the given assumptions.
	/*!
	 * The use of assumptions allows for incremental solving. Literals contained
   * in assumptions are assumed to be true during search but can be undone afterwards.
	 * 
	 * \param assumptions A list of unit assumptions to be assumed true.
	 * \return false if assumptions are conflicting.
	 */
	bool     assume(const LitVec& assumptions);

	//! Solves the path stored in the given solver using the given solving options.
	/*!
	 * \return
	 *    - value_true  if search stopped on a model.
	 *    - value_false if the search-space was completely examined.
	 *    - value_free  if the given solve limit was hit.
	 *
	 * \note 
	 *   The function maintains the current solving state (number of restarts, learnt limits, ...)
	 *   between calls. 
	 */
	ValueRep solve();
	//! Returns whether the given problem is satisfiable under the given assumptions.
	/*!
	 * Calls assume(assumptions) followed by solve() but does not maintain any solving state.
	 * \param init Call InitParams::randomize() before starting search?
	 */
	bool     satisfiable(const LitVec& assumptions, bool init);

	//! Resets the internal solving state while keeping the solver and the solving options.
	void     reset(bool reinit = false);
	//! Replaces *this with BasicSolve(s, p).
	void     reset(Solver& s, const SolveParams& p, SolveLimits* lim = 0);
	Solver&  solver() { return *solver_; }
private:
	BasicSolve(const BasicSolve&);
	BasicSolve& operator=(const BasicSolve&);
	typedef const SolveParams Params;
	typedef SolveLimits       Limits;
	struct State;
	Solver* solver_; // active solver
	Params* params_; // active solving options
	Limits* limits_; // active solving limits
	State*  state_;  // internal solving state
};
struct SolveEvent_t { enum Type {progress_msg = 1, progress_state = 2, progress_path = 3, progress_test = 4}; };
struct SolveMsgEvent : SolveEvent {
	SolveMsgEvent(const Solver& s, const char* m) : SolveEvent(s, SolveEvent_t::progress_msg), msg(m) {}
	const char* msg;
};
struct SolveStateEvent : SolveEvent {
	SolveStateEvent(const Solver& s, const char* m, double exitTime = -1.0) : SolveEvent(s, SolveEvent_t::progress_state), state(m), time(exitTime) {}
	const char* state; // state that is entered or left
	double      time;  // < 0: enter, else exit
};
struct SolvePathEvent : SolveEvent {
	enum EventType { event_none = 0, event_deletion = 'D', event_grow = 'G', event_model = 'M', event_restart = 'R', event_unsat = 'U' };
	SolvePathEvent(const Solver& s, EventType t, uint64 cLim, uint32 lLim) : SolveEvent(s, SolveEvent_t::progress_path), cLimit(cLim), lLimit(lLim), evType(t) {}
	uint64    cLimit; // next conflict limit
	uint32    lLimit; // next learnt limit
	EventType evType; // type of path event
};
///////////////////////////////////////////////////////////////////////////////
// General solve
///////////////////////////////////////////////////////////////////////////////
class Enumerator;

//! Interface for complex solve algorithms.
/*!
 * \ingroup solver
 * \relates Solver
 * SolveAlgorithms implement complex algorithms like enumeration or optimization.
 */
class SolveAlgorithm {
public:
	/*!
	 * \param lim    An optional solve limit applied in solve().
	 */
	explicit SolveAlgorithm(Enumerator* enumerator = 0, const SolveLimits& limit = SolveLimits());
	virtual ~SolveAlgorithm();

	//! Force termination of current solve process.
	/*!
	 * Shall return true if termination is supported, otherwise false.
	 */
	virtual bool      terminate()       { return false; }
	virtual bool      terminated()const { return false; }
	virtual uint64    hasErrors() const { return 0;     }
	const Enumerator& enumerator()const { return *enum_;  }
	void setEnumerator(Enumerator& e)   { enum_ = &e; }
	
	
	//! Runs the solve algorithm.
	/*!
	 * \param ctx    A fully initialized context object containing the problem.
	 * \param assume A list of initial unit-assumptions.
	 *
	 * \return
	 *  - true:  if the search stopped before the search-space was exceeded.
	 *  - false: if the search-space was completely examined.
	 *
	 * \note 
	 * The use of assumptions allows for incremental solving. Literals contained
	 * in assumptions are assumed to be true during search but are undone before solve returns.
	 * \note 
	 * The function is implemented in terms of beginSolve(ctx), doSolve(ctx, assume), endSolve(ctx).
	 */
	bool solve(SharedContext& ctx, const LitVec& assume = LitVec());

	virtual bool satisfiable(Solver& s, const LitVec& assume, const SolveParams& p, bool init) {
		return BasicSolve(s, p).satisfiable(assume, init);
	}
protected:
	SolveAlgorithm(const SolveAlgorithm&);
	SolveAlgorithm& operator=(const SolveAlgorithm&);
	//! Pre-Solve hook.
	virtual bool  beginSolve(SharedContext& /* ctx */);
	//! Post-Solve hook.
	/*!
	 * The default implementation calls Enumerator::reportResult() on the wrapped enumerator.
	 */
	virtual bool  endSolve(SharedContext& ctx, bool solveRet);
	//! The actual solve algorithm.
	/*!
	 * The default implmentation uses single-threaded (single solver) 
	 * sequential solving.
	 */
	virtual bool  doSolve(SharedContext& ctx, const LitVec& assume);
	
	const SolveLimits& solveLimits() const                  { return limits_; }
	void               setSolveLimits(const SolveLimits& x) { limits_ = x;    }
	Enumerator&        enumerator()                         { return *enum_;  }
private:
	SolveLimits limits_;
	Enumerator* enum_;
};
}
#endif
