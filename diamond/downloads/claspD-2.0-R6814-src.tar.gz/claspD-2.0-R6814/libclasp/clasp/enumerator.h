// 
// Copyright (c) 2006-2010, Benjamin Kaufmann
// 
// This file is part of Clasp. See http://www.cs.uni-potsdam.de/clasp/ 
// 
// Clasp is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// Clasp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Clasp; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//
#ifndef CLASP_ENUMERATOR_H_INCLUDED
#define CLASP_ENUMERATOR_H_INCLUDED

#ifdef _MSC_VER
#pragma once
#endif
#include <clasp/literal.h>
#include <clasp/constraint.h>
#include <clasp/util/misc_types.h>
#include <clasp/util/atomic.h>

namespace Clasp { 
class  Solver;
class  MinimizeConstraint;
struct SharedMinimizeData;
class  SharedContext;
class  SolveAlgorithm;

/**
 * \defgroup enumerator Enumerators and related classes
 */
//@{

//! Interface for enumerating models.
/*!
 * Enumerators are global w.r.t to one search operation, that is
 * even if the search operation itself is a parallel search, there
 * shall be only one enumerator and it is the user's responsibility
 * to protect the enumerator with appropriate locking.
 *
 * Concrete enumerators may create and install an enumeration constraint 
 * in each solver to support (parallel) enumeration.
 */
class Enumerator {
public:
	//! Interface used by the Enumerator to report model events.
	class Report : public ProgressReport {
	public:
		Report();
		//! The solver has found a new model.
		virtual void reportModel(const Solver& /* s */, const Enumerator& /* self */) {}
		//! Enumeration has terminated.
		virtual void reportSolution(const Enumerator& /* self */, bool /* complete */) {}
	};
	//! A solver-local (i.e. thread-local) constraint to support enumeration.
	class EnumeratorConstraint : public Constraint {
	public:
		using Constraint::minimize;
		EnumeratorConstraint();
		uint32              updates()   const { return updates_; }
		MinimizeConstraint* minimize()  const { return mini_; }
		void   setUpdates(uint32 u)           { updates_ = u; }
		void   setMinimize(Solver& s, MinimizeConstraint* m);
		//! Detaches and destroys minimize constraint if any.
		void   destroy(Solver* s, bool detach);
		//! Tries to update the constraint with information gained from other solvers during enumeration.
		bool   update(const Enumerator& ctx, Solver& s, bool disjointPath);
		//! Tries to relax the constraint after a root-level conflict was found in s.
		bool   relax(Enumerator& ctx, Solver& s, bool updateShared);
	protected:
		Constraint* cloneAttach(Solver& o);
		//! Activates minimize constraint on assignment of tag literal.
		PropResult  propagate(Solver&, Literal, uint32&);
		//! Restores minimize constraint on undo of tag literal.
		void        undoLevel(Solver&);
		//! Noop.
		void        reason(Solver&, Literal, LitVec&);
	private:
		virtual EnumeratorConstraint* clone(Solver& s) = 0;
		virtual bool                  doUpdate(const Enumerator& ctx, Solver& s, bool disjoint) = 0;
		MinimizeConstraint* mini_;
		uint32              updates_;
	};
	
	explicit Enumerator(Report* r = 0);
	virtual ~Enumerator();
	
	//! How to continue after a model was found.
	enum Result {
		enumerate_continue,      /**< Continue enumeration. */
		enumerate_stop_complete, /**< Stop because search space is exceeded.  */
		enumerate_stop_enough    /**< Stop because enough models have been enumerated. */
	};

	//! Sets the report callback to be used during enumeration.
	/*!
	 * \note Ownership is *not* transferred and r must be valid
	 * during complete search.
	 */
	void setReport(Report* r);
	
	//! Sets the (shared) minimize object to be used during enumeration.
	/*!
	 * \note Ownership is transferred.
	 */
	void setMinimize(SharedMinimizeData* min);
	const SharedMinimizeData* minimize() const { return mini_; }

	//! Sets the maximum number of models to enumerate and prepares the given problem for enumeration. 
	/*!
	 * The function shall be called once before search is started and before SharedContext::endInit()
	 * was called.
	 *
	 * \pre The problem is not yet frozen, i.e. SharedContext::endInit() was not yet called.
	 * \param problem   The problem on which enumeration should work.
	 * \param numModels Number of models to enumerate (0 means all models).
	 *
	 * \note In the incremental setting, enumerate() must be called once for each incremental step.
	 */
	void prepare(SharedContext& problem, uint64 numModels);

	bool enumerate() const { return numModels_ != 1; }
	
	uint64 enumerated; /**< Number of models enumerated so far. */

	//! Returns the enumeration constraint attached to s.
	EnumeratorConstraint* constraint(const Solver& s) const;

	//! Processes and returns from a model stored in the given solver.
	/*!
	 * The return value determines how search should proceed.
	 * If enumerate_continue is returned, the enumerator has
	 * removed at least one decision level and search should continue
	 * with a call to Enumerator::continueFromModel().
	 * Otherwise, the search shall be stopped.
	 * \pre The solver contains a model and DL = s.decisionLevel()
	 * \post If enumerate_continue is returned:
	 *  - s.decisionLevel() < DL and s.decisionLevel() >= s.rootLevel()
	 *
	 * \note The function is *not* concurrency-safe, i.e. in a parallel search
	 *       at most one solver shall call the function at any one time.
	 */
	Result backtrackFromModel(Solver& s);
	
	//! Processes an unsatisfiable path stored in the given solver.
	/*!
	 * The return value determines how search should proceed.
	 * If enumerate_continue is returned, the enumerator has
	 * relaxed at least one constraint and search should continue.
	 * Otherwise search should stop.
	 *
	 * \note The function is *not* concurrency-safe, i.e. in a parallel search
	 *       at most one solver shall call the function at any one time.
	 */
	Result backtrackFromUnsat(Solver& s, bool updateShared);
	
	//! Continues enumeration after a model was found.
	/*!
	 * Adds new information from the recent model and strengthens
	 * any conditional knowledge in s.
	 * \pre backtrackFromModel(s) was called and returned enumerate_continue.
	 * \return false if an unresolvable conflict was found.
	 *
	 * \note The function is concurrency-safe, i.e. can be called
	 *       concurrently by different solvers.
	 */
	bool continueFromModel(Solver& s, bool allowModelHeuristic = true);

	//! Updates solver s with new enumeration-related information.
	/*!
	 * The function is used to transfer information in
	 * parallel search. Whenever a solver s1 called backtrackFromModel()
	 * or backtrackFromUnsat(), all other solvers shall eventually call update() 
	 * to incorporate any new information.
	 * \note The function is concurrency-safe, i.e. can be called
	 *       concurrently by different solvers.
	 */
	bool update(Solver& s, bool disjointPath);

	//! Called once after search has stopped.
	/*!
	 * The function notifies the installed Report object.
	 */
	void reportResult(bool complete) {
		if (report_) report_->reportSolution(*this, complete);
	}
	//! Returns a value > 0 if optimization and > 1 if hierarchical optimization is active.
	int optimize() const;
	//! Returns whether or not this enumerator supports full restarts once a model was found.
	virtual bool supportsRestarts() const{ return true; }
	//! Returns whether or not this enumerator supports parallel search.
	virtual bool supportsParallel() const{ return true; }
protected:
	uint32 getHighestActiveLevel() const { return activeLevel_; }
	uint32 addUpdateMessage()            { return ++updates_; }
	virtual EnumeratorConstraint* doInit(SharedContext& ctx) = 0;
	virtual bool backtrack(Solver& s)   = 0;
	virtual bool updateModel(Solver& s) = 0;
	virtual bool ignoreSymmetric() const;
private:
	Enumerator(const Enumerator&);
	Enumerator& operator=(const Enumerator&);
	uint64              numModels_;
	Report*             report_;
	SharedMinimizeData* mini_;
	std::atomic<uint32> updates_;
	uint32              activeLevel_;
};

class NullEnumerator : public Enumerator {
public:
	NullEnumerator() {}
	class NullConstraint : public EnumeratorConstraint {
	public:
		typedef EnumeratorConstraint base_type;
		base_type* clone(Solver&)                             { return new NullConstraint(); }
		bool       doUpdate(const Enumerator&, Solver&, bool) { return true; }
	};
	static NullEnumerator& instance();
private:
	EnumeratorConstraint* doInit(SharedContext&) { return 0; }
	bool backtrack(Solver&)                      { return false; }
	bool updateModel(Solver&)                    { return false; }
};

//@}

}

#endif
