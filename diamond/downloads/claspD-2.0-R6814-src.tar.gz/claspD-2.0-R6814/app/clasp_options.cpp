// 
// Copyright (c) 2006-2012, Benjamin Kaufmann
// 
// This file is part of Clasp. See http://www.cs.uni-potsdam.de/clasp/ 
// 
// Clasp is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// Clasp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Clasp; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//
#include "clasp_options.h"
#include "program_opts/typed_value.h"  
#include "program_opts/composite_value_parser.h"  // pair and vector
#include <clasp/satelite.h>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <cstring>
#include <cctype>
#include <cfloat>
using namespace ProgramOptions;
using namespace std;
namespace ProgramOptions {
// Specialized function for mapping unsigned integers
// Parses numbers >= 0, -1, and the string umax
StringSlice parseValue(const StringSlice& in, uint32& x, int extra) {
	int t           = 0;
	StringSlice ret = parseValue(in, t, extra);
	if (ret.ok() && t >= -1) { x = static_cast<uint32>(t); return ret; }
	size_t p = 0;
	if      (in.size() >= 2 && std::strncmp(in.data(), "-1", 2) == 0)   { x = uint32(-1); p = 2; }
	else if (in.size() >= 4 && std::strncmp(in.data(), "umax", 4) == 0) { x = uint32(-1); p = 4; }
	ret = in.parsed(p > 0, p);
	return ret.ok () && (extra != 0 || ret.complete()) ? ret : in.parsed(false);
}
}
namespace Clasp { 
/////////////////////////////////////////////////////////////////////////////////////////
// Parseing & Mapping of options
/////////////////////////////////////////////////////////////////////////////////////////
template <class T, class U>
inline bool set_clamp(T& x, U v) { 
	Range<U> r((U)std::numeric_limits<T>::min(), (U)std::numeric_limits<T>::max());
	x = (T)r.clamp(v);
	return true;
}
#define SET(x, v)           ( ((x)=(v)) == (v) )
#define SET_LEQ(x, v, m)    ( ((v)<=(m)) && SET((x), (v)) )
#define SET_OR_FILL(x, v)   ( SET((x),(v)) || ((x) = 0, (x) = ~(x),true) ) 
#define SET_OR_ZERO(x,v)    ( SET((x),(v)) || SET((x),uint32(0)) )
#define SET_R(x, v, lo, hi) ( ((lo)<=(v)) && ((v)<=(hi)) && SET((x), (v)) )
#define SWITCH(n) for (const std::string& __name__ = (n);;)
#define CASE(n, m)   if ((n) == __name__) return (m);

// a little helper to make parsing more comfortable
template <class T>
inline bool parse(const std::string& str, T& out) {
	return ProgramOptions::DefaultParser<T>::parse(str, out);
}

bool isFlagNo(const std::string& x) {
	if (x == "no") { return true; }
	const ProgramOptions::FlagStr* t = ProgramOptions::FlagStr::find(x);
	return t && t->val == false;
}

// maps positional options to options number or file
bool parsePositional(const std::string& t, std::string& out) {
	int num;
	if   (parse(t, num)) { out = "number"; }
	else                 { out = "file";   }
	return true;
}

inline ProgramOptions::StringSlice skip(const ProgramOptions::StringSlice& in, char c) {
	if (!in.ok() || in.complete() || in.data()[0] != c) { return in; }
	return in.parsed(true, 1);
}

template <class T>
inline bool match(ProgramOptions::StringSlice& in, T& out, bool skipSep = true) {
	if (skipSep) { in = skip(in, ','); }
	return (in = parseValue(in, out, 1)).ok();
}

// overload for parsing a clasp schedule - needed
// to make parsing of schedule composable, e.g. in a pair 
ProgramOptions::StringSlice parseValue(const ProgramOptions::StringSlice& in, ScheduleStrategy& sched, int E) {
	typedef ScheduleStrategy::Type SchedType;
	std::string type;
	StringSlice next(in);
	if (match(next, type, false)) {
		uint32 base    = 0, add, limit = 1;
		double arg     = 0;
		bool ok        = false;
		type           = toLower(type);
		SchedType st   = ScheduleStrategy::geometric_schedule;
		if      (!match(next, base)|| base == 0){ return in.parsed(false); }
		else if (type == "f" || type == "fixed"){ st = ScheduleStrategy::arithmetic_schedule; ok = true; limit = 0; }
		else if (type == "l" || type == "luby") { st = ScheduleStrategy::luby_schedule;       ok = true; }
		else if (type == "+" || type == "add")  { st = ScheduleStrategy::arithmetic_schedule; ok = match(next, add); arg = add; }
		else if (type == "x" || type == "*")    { st = ScheduleStrategy::geometric_schedule;  ok = match(next, arg) && arg >= 1.0; }
		else if (type == "d" || type == "D")    { st = ScheduleStrategy::user_schedule;       ok = match(next, arg) && arg > 0.0; }
		if (!ok)        { return in.parsed(false); }
		if (limit == 1) { limit = 0; next = !next.complete() && next.data()[0] == ',' ? parseValue(next.parsed(true,1), limit, E) : next; }
		if (E == 0 && !next.complete()) { return in.parsed(false); }
		sched = ScheduleStrategy(st, base, arg, limit);
		return next;
	}
	return in.parsed(false);
}
// maps value to the corresponding enum-constant
// theMap must be null-terminated!
bool mapEnumImpl(const EnumMap* theMap, const std::string& value, int& out) {
	std::string temp(toLower(value));
	for (int i = 0; theMap[i].str; ++i) {
		if (temp == theMap[i].str) { 
			out = theMap[i].ev; 
			return true; 
		}
	}
	return false;
}
// statically binds theMap so that the resulting function can be
// used as parser in the ProgramOption-library
template <const EnumMap* theMap, class EnumT>
bool mapEnum(const std::string& value, EnumT& out) {
	int temp;
	return mapEnumImpl(theMap, value, temp) && (out = (EnumT)temp, true);
}
/////////////////////////////////////////////////////////////////////////////////////////
// Clasp specific mode options
/////////////////////////////////////////////////////////////////////////////////////////
void ModeOptions::initOptions(ProgramOptions::OptionContext& root) {
	GlobalOptions* global = config;
	OptionGroup general("Clasp - Mode Options");
	addSolveOptions(general);
	general.addOptions()
		("solve-limit", storeTo(global->solve.limit, &ModeOptions::parseSolveLimit)->arg("<n>[,<m>]"), "Stop search after <n> conflicts or <m> restarts\n")

		("enum-mode,e", storeTo(global->enumerate.mode, &mapEnum<enumModes>)->defaultsTo("auto")->state(Value::value_defaulted), 
		 "Configure enumeration algorithm [%D]\n"
		 "      %A: {bt|record|brave|cautious|auto}\n"
		 "        bt      : Backtrack decision literals from solutions\n"
		 "        record  : Add nogoods for computed solutions\n"
		 "        brave   : Compute brave consequences (union of models)\n"
		 "        cautious: Compute cautious consequences (intersection of models)\n"
		 "        auto    : Use bt for enumeration and record for optimization")
		("number,n", storeTo(global->enumerate.numModels)->arg("<n>"), "Compute at most %A models (0 for all)")
		("project"           , flag(global->enumerate.project)       , "Project models to named atoms in enumeration mode\n")
		("project-opt,@2", storeTo(global->enumerate.projectOpts), "Additional options for projection as octal digit")
		
		("opt-ignore"        , flag(global->opt.no) ,                  "Ignore optimize statements")
		("opt-sat"           , flag(global->enumerate.maxSat), "Treat DIMACS input as MaxSAT optimization problem")
		("opt-hierarch"      , storeTo(global->opt.hierarch)->arg("{0..3}")->implicit("1"), 
		 "Process optimize statements in order of priority\n"
		 "    For each criterion use:\n"
		 "      1: fixed step size of one\n"
		 "      2: exponentially increasing step sizes\n"
		 "      3: exponentially decreasing step sizes")
		("opt-all"           , notify(this, &ModeOptions::mapOptVal)->arg("<opt>..."), "Compute models <= %A")
		("opt-value"         , notify(this, &ModeOptions::mapOptVal)->arg("<opt>..."), "Initialize objective function(s)\n")
	;
	OptionGroup asp("Clasp - ASP Options");
	asp.addOptions()
		("pre" , flag(global->enumerate.onlyPre), "Run ASP preprocessing and exit")
		("supp-models",flag(global->eq.noSCC), "Compute supported models (no unfounded set check)")
		("eq,@1", storeTo(global->eq.iters)->arg("<n>"), "Configure equivalence preprocessing\n"
		"      Run for at most %A iterations (-1=run to fixpoint)")
		("backprop!,@1",flag(global->eq.backprop), "Use backpropagation in ASP-preprocessing")
		("no-gamma,@1" ,flag(global->eq.noGamma), "Do not add gamma rules for non-hcf disjunctions")
		("eq-dfs,@2"   ,flag(global->eq.dfOrder), "Enable df-order in eq-preprocessing")
		("trans-ext!,@1", storeTo(global->eq.erMode, &mapEnum<extRules>),
		 "Configure handling of Lparse-like extended rules\n"
		 "      %A: {all|choice|card|weight|integ|dynamic}\n"
		 "        all    : Transform all extended rules to basic rules\n"
		 "        choice : Transform choice rules, but keep cardinality and weight rules\n"
		 "        card   : Transform cardinality rules, but keep choice and weight rules\n"
		 "        weight : Transform cardinality and weight rules, but keep choice rules\n"
		 "        scc    : Transform \"recursive\" cardinality and weight rules\n"
		 "        integ  : Transform cardinality integrity constraints\n"
		 "        dynamic: Transform \"simple\" extended rules, but keep more complex ones")
	;
	root.add(general);
	root.add(asp);
}
const EnumMap ModeOptions::extRules[] = {
	{"all", ProgramBuilder::mode_transform}, {"yes", ProgramBuilder::mode_transform},
	{"no", ProgramBuilder::mode_native}, {"0", ProgramBuilder::mode_native},
	{"choice", ProgramBuilder::mode_transform_choice}, {"card", ProgramBuilder::mode_transform_card},
	{"weight", ProgramBuilder::mode_transform_weight}, {"scc", ProgramBuilder::mode_transform_scc},
	{"integ", ProgramBuilder::mode_transform_integ}, {"dynamic", ProgramBuilder::mode_transform_dynamic}, 
	{0, 0}
};
const EnumMap ModeOptions::enumModes[]= {
	{"auto", GlobalOptions::enum_auto}, {"bt", GlobalOptions::enum_bt},
	{"record", GlobalOptions::enum_record}, {"brave", GlobalOptions::enum_brave},
	{"cautious", GlobalOptions::enum_cautious}, {0,0}
};

bool ModeOptions::mapOptVal(ModeOptions* this_, const std::string& n, const std::string& value) {
	GlobalOptions* global = this_->config;
	if (parseSequence<wsum_t>(StringSlice(value), std::back_inserter(global->opt.vals), -1, 0)) {
		if (n == "opt-all") { global->opt.all = true; }
		return true;
	}
	global->opt.vals.clear();
	return false;
}
bool ModeOptions::validateOptions(const ProgramOptions::OptionContext&, const ProgramOptions::ParsedOptions& vm, Messages& m) {
	if (config->eq.noSCC && vm.count("eq") == 0)  { config->eq.noEq(); }
	if (vm.count("opt-value") && config->opt.all) { m.error = "'opt-all' and 'opt-value' are mutually exclusive!"; }
	return m.error.empty();
}
bool ModeOptions::parseSolveLimit(const std::string& s, SolveLimits& limit) {
	std::pair<uint32, uint32> p(-1, -1);
	if (s != "no" && !parse(s, p)) { return false; }
	limit = SolveLimits(p.first, p.second);
	if (limit.conflicts == UINT32_MAX) { limit.conflicts = UINT64_MAX; }
	if (limit.restarts  == UINT32_MAX) { limit.restarts  = UINT64_MAX; }
	return true;
}
/////////////////////////////////////////////////////////////////////////////////////////
// Clasp specific search options
/////////////////////////////////////////////////////////////////////////////////////////
const std::string searchGroup   = "Clasp - Search Options";
const std::string lookbackGroup = "Clasp - Lookback Options";
SearchOptions::SearchOptions(const SolverConfig& o) : config(o) {}
void SearchOptions::initOptions(ProgramOptions::OptionContext& root) {
	// NOTE: DO NOT bind locations to options (e.g. via. storeTo/flag) here
	// but instead only use indirect (notify) values. This way,
	// when parsing a portfolio, only the underlying solver configuration 
	// (one pointer) has to change, while the context holding the 
	// option-instances can remain the same.
	OptionGroup search(searchGroup, ProgramOptions::desc_level_e1);
	search.addOptions()
		("restart-on-model", notify(this, &SearchOptions::mapSolverOpts)->flag(), "Restart after each model")
		("heuristic", notify(this, &SearchOptions::mapSolverOpts), 
		 "Configure decision heuristic\n"
		 "      %A: {Berkmin|Vmtf|Vsids|Unit|None}\n"
		 "        Berkmin: Apply BerkMin-like heuristic\n"
		 "        Vmtf   : Apply Siege-like heuristic\n"
		 "        Vsids  : Apply Chaff-like heuristic\n"
		 "        Unit   : Apply Smodels-like heuristic (Default if --no-lookback)\n"
		 "        None   : Select the first free variable")
		("init-moms!,@2", notify(this, &SearchOptions::mapSolverOpts)->flag(), "Initialize heuristic with MOMS-score")
		("score-other", notify(this, &SearchOptions::mapSolverOpts)->arg("<n>"), "Score {0=no|1=loop|2=all} other learnt nogoods")
		("sign-def", notify(this, &SearchOptions::mapSolverOpts)->arg("<n>"), "Default sign: {0=type|1=no|2=yes|3=rnd}")
		("disj-true!,@2",notify(this, &SearchOptions::mapSolverOpts)->flag(), "Use body as default type for atoms in disjunctions")
		("sign-fix!", notify(this, &SearchOptions::mapSolverOpts)->flag(), "Disable sign heuristics and use default signs only")
		("berk-max,@2", notify(this, &SearchOptions::mapSolverOpts)->arg("<n>"), "Consider at most %A nogoods in Berkmin heuristic")
		("berk-huang!,@2",notify(this, &SearchOptions::mapSolverOpts)->flag(), "Enable/Disable Huang-scoring in Berkmin")
		("berk-once!,@2",notify(this, &SearchOptions::mapSolverOpts)->flag(), "Score sets (instead of multisets) in Berkmin")
		("vmtf-mtf,@2", notify(this, &SearchOptions::mapSolverOpts)->arg("<n>"), "In Vmtf move %A conflict-literals to the front")
		("vsids-decay,@2", notify(this, &SearchOptions::mapSolverOpts)->arg("<n>"), "In Vsids use 1.0/0.<n> as decay factor")
		("nant!,@2",notify(this, &SearchOptions::mapSolverOpts)->flag(), "In Unit count only atoms in NAnt(P)")
		("opt-heuristic" , notify(this, &SearchOptions::mapSolverOpts)->implicit("1")->arg("{0..3}"), 
		 "Use opt. in {1=sign|2=model|3=both} heuristics")
		("partial-check" , notify(this, &SearchOptions::mapSearchOpts)->implicit("50"), 
		 "Configure partial stability tests\n"
		 "      %A: <p>[,<h>][,<x>] / Implicit: %I\n"
		 "        <p>: Partial check percentage\n"
		 "        <h>: Initial value for high bound (0 = umax)\n"
		 "        <x>: Increase (1) or keep (0) high bound once reached")
		("save-progress"   , notify(this, &SearchOptions::mapSolverOpts)->implicit("1")->arg("<n>"), "Use RSat-like progress saving on backjumps > %A")
		("rand-freq", notify(this, &SearchOptions::mapSearchOpts)->arg("<p>"), "Make random decisions with probability %A")
		("init-watches", notify(this, &SearchOptions::mapSolverOpts)->arg("{0..2}")->defaultsTo("1"),
		 "Configure watched literal initialization [%D]\n"
		 "      Watch {0=first|1=random|2=least watched} literals in nogoods")
		("seed"    , notify(this, &SearchOptions::mapSolverOpts)->arg("<n>"),"Set random number generator's seed to %A\n")		
		
		("lookahead!"     ,notify(this, &SearchOptions::mapSearchOpts)->implicit("atom"),
		 "Configure failed-literal detection (fld)\n"
		 "      %A: <type>[,<n {1..umax}>] / Implicit: %I\n"
		 "        <type>: Run fld via {atom|body|hybrid} lookahead\n"
		 "        <n>   : Disable fld after <n> applications ([-1]=no limit)\n"
		 "      --lookahead=atom is default if --no-lookback is used\n")

		("rand-prob!", notify(this, &SearchOptions::mapSearchOpts)->implicit("10,100"),
		 "Configure random probing (Implicit: %I)\n"
		 "      %A: <n1>[,<n2>]\n"
		 "        Run <n1> random passes with at most <n2> conflicts each")
	;
	
	OptionGroup lookback(lookbackGroup, ProgramOptions::desc_level_e1);
	lookback.addOptions()
		("no-lookback"   , notify(this, &SearchOptions::mapSolverOpts)->flag(), "Disable all lookback strategies\n")
		
		("restarts!,r", notify(this, &SearchOptions::mapRestart)->arg("<sched>"),
		 "Configure restart policy\n"
		 "      %A: <type {D|F|L|x|+}>,<n {1..umax}>[,<args>][,<lim>]\n"
		 "        F,<n>    : Run fixed sequence of <n> conflicts\n"
		 "        L,<n>    : Run Luby et al.'s sequence with unit length <n>\n"
		 "        x,<n>,<f>: Run geometric seq. of <n>*(<f>^i) conflicts  (<f> >= 1.0)\n"
		 "        +,<n>,<m>: Run arithmetic seq. of <n>+(<m>*i) conflicts (<m {0..umax}>)\n"
		 "        ...,<lim>: Repeat seq. every <lim>+j restarts           (<type> != F)\n"
		 "        D,<n>,<f>: Restart based on moving LBD average over last <n> conflicts\n"
		 "                   Mavg(<n>,LBD)*<f> > avg(LBD)\n"
		 "                   use conflict level average if <lim> > 0 and avg(LBD) > <lim>\n"
		 "      no|0       : Disable restarts")
		("reset-restarts"  , notify(this, &SearchOptions::mapRestart)->arg("0..2")->implicit("1"), "{0=Keep|1=Reset|2=Disable} restart seq. after model")
		("local-restarts"  , notify(this, &SearchOptions::mapRestart)->flag(), "Use Ryvchin et al.'s local restarts")
		("counter-restarts", notify(this, &SearchOptions::mapRestart)->arg("<n>"), "Do a counter implication restart every <n> restarts")
		("counter-bump,@2" , notify(this, &SearchOptions::mapRestart)->arg("<n>"), "Set CIR bump factor to %A")
		("shuffle!"        , notify(this, &SearchOptions::mapRestart)->arg("<n1>,<n2>"), "Shuffle problem after <n1>+(<n2>*i) restarts\n")

		("deletion!,d", notify(this, &SearchOptions::mapReduceOpts)->defaultsTo("1,75,3.0")->state(Value::value_defaulted), 
		 "Configure deletion strategy [%D]\n"
		 "      %A: <s {1..3}>[,<n {1..100}>][,<f>]\n"
		 "        <s>: Enable {1=size-based|2=conflict-based|3=combined} strategy\n"
		 "        <n>: Delete at most <n>%% of nogoods on reduction       [75]\n"
		 "        <f>: Set initial limit to P=estimated problem size/<f> [3.0]\n"
		 "      no   : Disable nogood deletion")
		("del-init-r", notify(this, &SearchOptions::mapReduceOpts)->arg("<n>,<o>"), "Clamp initial limit to the range [<n>,<n>+<o>]")
		("del-estimate", notify(this, &SearchOptions::mapReduceOpts)->flag(), "Use estimated problem complexity in limits")
		("del-max",  notify(this, &SearchOptions::mapReduceOpts)->arg("<n>,<X>"), "Keep at most <n> learnt nogoods taking up to <X> MB")
		("del-grow", notify(this, &SearchOptions::mapReduceOpts), 
		 "Configure size-based deletion policy\n"
		 "      %A: <f>[,<g>][,<sched>] (<f> >= 1.0 / deletion.<s> in {1|3})\n"
		 "        <f>     : Keep at most T = X*(<f>^i) learnt nogoods with X being the\n"
		 "                  initial limit and i the number of times <sched> fired\n"
		 "        <g>     : Stop growth once T > P*<g> (0=no limit)      [3.0]\n"
		 "        <sched> : Set grow schedule (<type {F|L|x|+}>) [grow on restart]")
		("del-cfl", notify(this, &SearchOptions::mapReduceOpts)->arg("<sched>"), 
		 "Configure conflict-based deletion policy\n"
		 "      %A:   <t {F|L|x|+}>,<n {1..umax}>[,<args>][,<lim>] (see restarts)\n"
		 "      condition: deletion.<s> in {2|3}")
		("del-algo", notify(this, &SearchOptions::mapReduceOpts), 
		 "Configure nogood deletion algorithm\n"
		 "      %A: <algo>[,<sc {0..2}>]\n"
		 "        <algo>: Use {basic|sort|inp_sort|inp_heap} algorithm\n"
		 "        <sc>  : Use {0=activity|1=lbd|2=combined} nogood scores [0]")
		("del-glue", notify(this, &SearchOptions::mapReduceOpts), "Configure glue clause handling\n"
		 "      %A: <n {0..127}>[,<m {0|1}>]\n"
		 "        <n>: Do not delete nogoods with LBD <= <n>\n"
		 "        <m>: Count (0) or ignore (1) glue clauses in size limit [0]")
		("del-on-restart", notify(this, &SearchOptions::mapReduceOpts)->arg("<n>")->implicit("33"), "Delete %A%% of learnt nogoods on each restart\n")
	
		("strengthen!", notify(this, &SearchOptions::mapSolverOpts),
		 "Use MiniSAT-like conflict nogood strengthening\n"
		 "      %A: <mode>[,<type>]\n"
		 "        <mode>: Use {local|recursive} self-subsumption check\n"
		 "        <type>: Follow {0=all|1=short|2=binary} antecedents  [0]")
		("otfs",notify(this, &SearchOptions::mapSolverOpts)->implicit("1")->arg("{0..2}"), "Enable {1=partial|2=full} on-the-fly subsumption")
		("update-lbd", notify(this, &SearchOptions::mapSolverOpts)->implicit("1")->arg("{0..3}"), "Update LBDs of learnt nogoods {1=<|2=strict<|3=+1<}")
		("update-act,@2", notify(this, &SearchOptions::mapSolverOpts)->flag(), "Enable LBD-based activity bumping")
		("update-mode,@2", notify(this, &SearchOptions::mapSolverOpts)->defaultsTo("0"), "Process messages on {0=propagation|1=conflict)")
		("reverse-arcs",notify(this, &SearchOptions::mapSolverOpts)->implicit("1")->arg("{0..3}"), "Enable ManySAT-like inverse-arc learning")
		("contraction!", notify(this, &SearchOptions::mapSolverOpts)->arg("<n>"),
		 "Contract learnt nogoods of size > <n> (0=disable)\n")
		
		("loops", notify(this, &SearchOptions::mapSolverOpts),
			"Configure learning of loop nogoods\n"
			"      %A: {common|distinct|shared|no}\n"
			"        common  : Create loop nogoods for atoms in an unfounded set\n"
			"        distinct: Create distinct loop nogood for each atom in an unfounded set\n"
			"        shared  : Create loop formula for a whole unfounded set\n"
			"        no      : Do not learn loop formulas")
	;
	root.add(search);
	root.add(lookback);
}

void SearchOptions::initOptions(const ProgramOptions::OptionContext& global, ProgramOptions::OptionContext& out, const SolverConfig& x) {
	if (!out.tryFindGroup(searchGroup)) {
		const OptionGroup* s = global.tryFindGroup(searchGroup);
		const OptionGroup* l = global.tryFindGroup(lookbackGroup);
		if (s && l) { out.add(*s); out.add(*l); }
		else        { initOptions(out); }
	}
	this->config = x;
}
const EnumMap SearchOptions::heuTypes[] = {
	{"berkmin", Heuristic::heu_berkmin}, {"vmtf", Heuristic::heu_vmtf},
	{"vsids", Heuristic::heu_vsids}, {"unit", Heuristic::heu_unit},
	{"none", Heuristic::heu_none}, {0,0}
};
const EnumMap SearchOptions::loopTypes[] = {
	{"common", DefaultUnfoundedCheck::common_reason}, {"shared", DefaultUnfoundedCheck::shared_reason},
	{"distinct", DefaultUnfoundedCheck::distinct_reason}, {"no", DefaultUnfoundedCheck::only_reason},
	{0,0}
};
const EnumMap SearchOptions::lookTypes[] = {
	{"atom", Lookahead::atom_lookahead}, {"body", Lookahead::body_lookahead}, {"hybrid", Lookahead::hybrid_lookahead},
	{0,0}
};
const EnumMap SearchOptions::delAlgos[] = {
	{"basic", ReduceStrategy::reduce_linear}, {"sort", ReduceStrategy::reduce_stable},
	{"inp_sort", ReduceStrategy::reduce_sort}, {"inp_heap", ReduceStrategy::reduce_heap}, 
	{0,0}
};

bool SearchOptions::parseSchedule(const std::string& s, ScheduleStrategy& sched, bool allowNo) {
	if (allowNo && isFlagNo(s)) { sched = ScheduleStrategy::none(); return true; }
	return parseValue(StringSlice(s), sched, 0).ok();
}

bool SearchOptions::mapRestart(SearchOptions* this_, const std::string& n, const std::string& value) {
	RestartParams& p = this_->config.search->restart;
	bool b; uint32 x;
	SWITCH(n) {
		CASE("restarts"        , (parseSchedule(value, p.sched, true) && SET(p.dynRestart, uint32(p.sched.type == ScheduleStrategy::user_schedule))));
		CASE("local-restarts"  , (FlagStr::store_true(value, b) && SET(p.cntLocal, uint32(b))));
		CASE("counter-restarts", (parse(value, x) && set_clamp(p.counterRestart, x)));
		CASE("counter-bump"    , (parse(value, x) && set_clamp(p.counterBump, x)));
		CASE("reset-restarts"  , (parse(value, x) && SET_LEQ(p.upRestart, x, 2u)));
		if (n == "shuffle") {
			std::pair<uint32, uint32> x(0,0);
			return (isFlagNo(value) || parse(value, x)) && SET_OR_FILL(p.shuffle, x.first) && SET_OR_FILL(p.shuffleNext, x.second);
		}
		return false;
	}
}

bool SearchOptions::mapReduceOpts(SearchOptions* this_, const std::string& n, const std::string& value) {
	ReduceParams& p = this_->config.search->reduce;
	if (n == "deletion") { // <s>[,<n>][,<f>]
		if (isFlagNo(value)) { p.strategy.scheds = ReduceStrategy::sched_no; return true; }
		std::pair<uint32, std::pair<uint32, double> > arg(0, std::make_pair(75, 3.0)); 
		return parse(value, arg) && SET_LEQ(p.strategy.scheds, arg.first, 3) && SET_R(p.strategy.fReduce, arg.second.first, 1, 100) 
		  &&   arg.second.second > 0 && (p.fInit = float(1.0 / arg.second.second)) > 0;
	}
	else if (n == "del-init-r") { // <b>,<o>
		std::pair<uint32, uint32> arg(p.initRange.lo, p.initRange.hi);
		return parse(value, arg) && SET(p.initRange.lo, arg.first) && set_clamp(p.initRange.hi, uint64(arg.first)+arg.second);
	}
	else if (n == "del-grow") { // <g>[,<h>][,<sched>]
		std::pair<std::pair<double, double>, ScheduleStrategy> arg(std::make_pair(1.0, 3.0), p.growSched);
		return parse(value, arg) && SET_R(p.fGrow, (float)arg.first.first, 1.0f, FLT_MAX)
		  &&   SET_R(p.fMax, (float)arg.first.second, 1.0f, FLT_MAX)
		  &&   (p.growSched = arg.second, true);
	}
	else if (n == "del-algo") {
		std::pair<std::string, uint32> algo("", (uint32)p.strategy.score); int a;
		return parse(value, algo) && mapEnumImpl(delAlgos, algo.first, a) 
		  &&   SET_LEQ(p.strategy.score, algo.second, 2)
		  &&   SET(p.strategy.algo, (uint32)a);
	}
	else if (n == "del-glue"){
		std::pair<uint32, uint32> x(0, 0);
		return parse(value, x) && SET_LEQ(p.strategy.glue, x.first, (uint32)Activity::MAX_LBD)
		  &&   SET(p.strategy.noGlue, x.second);
	}
	else if (n == "del-max")       { 
		std::pair<uint32, uint32> x(0,0); 
		return parse(value, x) && SET_R(p.maxRange, x.first, 1u, UINT32_MAX) && SET_OR_ZERO(this_->config.solver->memLimit, x.second);
	}
	else if (n == "del-on-restart"){ uint32 x; return parse(value, x) && SET_LEQ(p.strategy.fRestart, x, 100); }
	else if (n == "del-estimate")  { bool x;   return FlagStr::store_true(value, x); p.strategy.estimate = (uint32)x; }
	else if (n == "del-cfl")       { return parseSchedule(value, p.cflSched, false); }
	return false;
}

bool SearchOptions::mapSolverOpts(SearchOptions* this_, const std::string& n, const std::string& v) {
	SolverStrategies* s = this_->config.solver;
	uint32 value        = 0;
	if      (n == "heuristic")  { int i; return mapEnumImpl(heuTypes, v, i) && SET(s->heuId, (uint32)i);  }
	else if (n == "loops")      { int i; return mapEnumImpl(loopTypes, v, i)&& SET(s->loopRep, (uint32)i);}
	else if (n == "strengthen") {
		std::pair<std::string, uint32> x("local", SolverStrategies::no_antes); bool b = false;
		if      (isFlagNo(v))                    { s->ccMinAntes = 0; s->strRecursive = 0; return true; }
		else if (!parse(v, x))                   { return false; }
		else if (x.first == "recursive")         { b = true; }
		else if (x.first != "local")             { return false; }
		return SET_R(s->ccMinAntes, x.second+1, 1u, 3u) && SET(s->strRecursive, (uint32)b);
	}
	else if (v != "no" && !parse(v, value))    { return false; }
	SWITCH(n) {
		CASE("restart-on-model", SET_LEQ(s->restartOnModel, value, 1u));
		CASE("contraction"  , SET_OR_ZERO(s->compress, value));
		CASE("init-watches" , SET_LEQ(s->initWatches, value, 2u));
		CASE("opt-heuristic", SET_LEQ(s->optHeu, value, 3u));
		CASE("otfs"         , SET_LEQ(s->otfs, value, 2u));
		CASE("save-progress", SET_OR_FILL(s->saveProgress, value));
		CASE("reverse-arcs" , SET_LEQ(s->reverseArcs, value, 3u));
		CASE("update-lbd"   , SET_LEQ(s->updateLbd, value, 3u));
		CASE("update-act"   , SET_LEQ(s->bumpVarAct, value, 1u));
		CASE("update-mode"  , SET_LEQ(s->upMode, value, 1u));
		CASE("no-lookback"  , SET_LEQ(s->search, value, 1u));
		CASE("berk-max"     , SET_OR_ZERO(s->heuParam, value));
		CASE("vmtf-mtf"     , SET_OR_FILL(s->heuParam, value));
		CASE("vsids-decay"  , SET_OR_FILL(s->heuParam, value)); 
		CASE("sign-def"     , SET_LEQ(s->signDef, value, 3u));
		CASE("disj-true"    , SET_LEQ(s->disjTrue,value, 1u));
		CASE("score-other"  , SET_LEQ(s->heuOther,value, 2u));
		CASE("sign-fix"     , SET_LEQ(s->signFix, value, 1u));
		CASE("nant"         , SET_LEQ(s->unitNant, value,1u));
		CASE("berk-once"    , SET_LEQ(s->berkOnce, value, 1u));
		CASE("berk-huang"   , SET_LEQ(s->berkHuang, value,1u));
		CASE("init-moms"    , SET_LEQ(s->heuMoms, value,  1u));
		CASE("seed"         , (s->rng.srand(value), true));
		return false;
	}
}

bool SearchOptions::mapSearchOpts(SearchOptions* this_, const std::string& n, const std::string& v) {
	SolveParams& params = *this_->config.search;
	if (n == "lookahead")     {
		std::pair<std::string, uint32> x("",-1); 
		int i = Lookahead::no_lookahead;
		if (!isFlagNo(v) && (!parse(v, x) || !mapEnumImpl(lookTypes, x.first, i) || x.second == 0)) { return false; }
		return SET(params.init.lookType, static_cast<Lookahead::Type>(i))
		  &&   set_clamp(this_->config.search->init.lookOps, x.second == UINT32_MAX ? uint32(0) : x.second);
	}
	else if (n == "partial-check") { 
		SolveParams::FwdCheck& chk = params.fwdCheck;
		uint32 seq[3] = {0,0,0};
		return parseSequence<uint32>(v, seq, 3, 0) 
		  &&   SET_LEQ(chk.highPct, seq[0], 100) && SET_OR_ZERO(chk.initHigh, seq[1]) && SET_LEQ(chk.incHigh, seq[2], 1u); 
	}
	else if (n == "rand-freq") {
		double f = 0.0;
		return (isFlagNo(v) || parse(v, f)) && SET_R(params.randProb, (float)f, 0.0f, 1.0f);
	}
	else if (n == "rand-prob") {
		std::pair<uint32, uint32> p(0,100);
		return (isFlagNo(v) || parse(v, p)) && params.init.setRandomizeParams(p.first, p.second);
	}
	return false;
}

bool SearchOptions::validateOptions(const ProgramOptions::OptionContext&, const ProgramOptions::ParsedOptions& vm, Messages& m) {
	if (config.solver->search == Clasp::SolverStrategies::no_learning) {	
		if (vm.count("heuristic") == 0) { config.solver->heuId         = Heuristic::heu_unit; }
		if (vm.count("lookahead") == 0) { config.search->init.lookType = Lookahead::atom_lookahead;  }
		if (Heuristic::isLookback(config.solver->heuId)) { m.error = "Selected heuristic requires lookback strategy!";}
		const RestartParams& rs   = config.search->restart;
		const ReduceParams&  rd   = config.search->reduce;
		bool warnRs = rs.local() || rs.dynamic() || rs.update() || rs.shuffle || rs.counterRestart || vm.count("restarts");
		bool warnRd = !rd.cflSched.disabled() || !rd.growSched.disabled() || vm.count("deletion");
		if (warnRs || warnRd || vm.count("strengthen") || vm.count("otfs") || vm.count("reverse-arcs")) {
			m.warning.push_back("'no-lookback': lookback options are ignored!");
		}
	}
	ReduceParams& p = config.search->reduce;
	if (p.strategy.scheds != ReduceStrategy::sched_both) {
		uint32 sched= p.strategy.scheds;
		uint32 grow = vm.count("del-grow") != 0 ? ReduceStrategy::sched_grow : 0;
		uint32 cfl  = vm.count("del-cfl") != 0  ? ReduceStrategy::sched_cfl  : 0;
		if ((sched & grow) != grow) { m.error = "'--del-grow': strategy not enabled by 'deletion'!"; }
		if ((sched & cfl)  != cfl)  { m.error = "'--del-cfl': strategy not enabled by 'deletion'!"; }
		if (sched == ReduceStrategy::sched_cfl && p.cflSched.disabled()) { m.error = "'deletion=2' requires '--del-cfl'!"; }
		if ((sched & ReduceStrategy::sched_grow) == 0) { p.growSched = ScheduleStrategy::none(); p.fGrow = 1.0f; p.fMax = 0; }
		if ((sched & ReduceStrategy::sched_cfl) == 0)  { p.cflSched  = ScheduleStrategy::none(); }
	}
	if (!p.cflSched.disabled() && p.cflSched.type == ScheduleStrategy::user_schedule) {
		m.error = "'--del-cfl': dynamic schedule 'D' not supported!";
	}
	else if (!p.growSched.disabled() && p.growSched.type == ScheduleStrategy::user_schedule) {
		m.error = "'--del-grow': dynamic schedule 'D' not supported!";
	}
	return m.error.empty();
}

/////////////////////////////////////////////////////////////////////////////////////////
// clasp option validation
/////////////////////////////////////////////////////////////////////////////////////////
void OptionConfig::initFromRaw(const char* raw) {
	assert(raw);
	while (std::isspace(static_cast<unsigned char>(*raw))) { ++raw; }
	const char* n = raw+1;
	const char* e = strchr(raw, ']');
	if (*raw == '[' && e != 0 && e[1] == ':') {
		name.assign(n, e);
		for (e += 2; std::isspace(static_cast<unsigned char>(*e)); ++e) { ; }
		cmdLine = e;
	}
	else { 
		std::string err("Invalid configuration: '");
		uint32 len = strlen(raw);
		err.append(raw, raw + std::min(len, uint32(20)));
		err += "'";
		throw std::logic_error(err);
	}
}
void ClaspOptions::initOptions(ProgramOptions::OptionContext& root, ClaspConfig& config) {
	this->clasp   = &config;
	this->active  = &config;
	genTemplate   = false;
	satPreParsed  = false;
	testerOpts    = "";
	initCommandOptions(root);
	mode.reset(new ModeOptions(&config.mode));
	mode->initOptions(root);
	initSearchOptions(root);
}

void ClaspOptions::initCommandOptions(ProgramOptions::OptionContext& root) {
	OptionGroup cmdOps("Clasp - Command Options");
	cmdOps.addOptions() 
		("configuration", notify(this, &ClaspOptions::mapDefaultConfig)->defaultsTo("frumpy"),
		 "Configure default configuration [%D]\n"
		 "      %A: {frumpy|jumpy|handy|crafty|trendy}\n"
		 "        frumpy: Use conservative defaults\n"
		 "        jumpy : Use aggressive defaults\n"
		 "        handy : Use defaults geared towards large problems\n"
		 "        crafty: Use defaults geared towards crafted problems\n"
		 "        trendy: Use defaults geared towards industrial problems")
		("tester", storeTo(testerOpts)->arg("<options>"), "Pass (quoted) string of <options> to tester\n")
	; 
	OptionGroup ctxOpts("Clasp - General Options", ProgramOptions::desc_level_e1);
	addMtCtxOptions(ctxOpts);
	ctxOpts.addOptions() 
		("sat-prepro,@1", notify(this, &ClaspOptions::mapCtxOpts)->implicit("-1"),
		 "Run SatELite-like preprocessing (Implicit: %I)\n"
		 "      %A: <n1>[,...][,<n5 {0..2}>] (-1=no limit)\n"
		 "        <n1>: Run for at most <n1> iterations\n"
		 "        <n2>: Run variable elimination with cutoff <n2>              [-1]\n"
		 "        <n3>: Run for at most <n3> seconds                           [-1]\n"
		 "        <n4>: Disable if <n4>%% of vars are frozen                    [-1]\n"
		 "        <n5>: Run blocked clause elimination  {0=no,1=limited,2=full} [1]\n")
		
		("learn-explicit,@1", notify(this, &ClaspOptions::mapCtxOpts)->flag(), "Do not use Short Implication Graph for learning\n")
	;
	root.add(cmdOps);	
	root.add(ctxOpts);
}

void ClaspOptions::initSearchOptions(ProgramOptions::OptionContext& root) {
	SearchOptions::SolverConfig sc(active->addSolver(0), active->addSearch(0));
	search.reset(new SearchOptions(sc));
	search->initOptions(root);
}

bool ClaspOptions::mapDefaultConfig(ClaspOptions* this_, const std::string&, const std::string& value) {
	const char* x = defConfigs_g;
	for (; *x && strncmp(x+1, value.c_str(), value.size()) != 0; x += strlen(x) + 1) { ; }
	return *(this_->defConfig = x) != 0;
}
const EnumMap shareModes[] = {
	{"all", ContextOptions::share_all}, {"problem", ContextOptions::share_problem}, {"learnt", ContextOptions::share_learnt}, {"no", ContextOptions::share_no},
	{0,0}
};
bool ClaspOptions::mapCtxOpts(ClaspOptions* this_, const std::string& key, const std::string& value) {
	ContextOptions* ctx = this_->active->context();
	if (key == "sat-prepro") {
		std::auto_ptr<SatElite::SatElite> pre(new SatElite::SatElite());
		uint32* pos = &pre->options.maxIters, *end = pos + (sizeof(pre->options)/sizeof(uint32)); 
		return parseSequence<uint32>(StringSlice(value), pos, uint32(end - pos), 0)
		  &&   (pre->options.maxIters == 0 || (this_->active->setSatPrepro(pre.release()), true));
	}
	else if (key == "learn-explicit") {
		bool x;
		return FlagStr::store_true(value, x) && SET(ctx->shortMode, uint32(x));
	}
	else if (key == "share") {
		int i = ContextOptions::share_no;
		return (isFlagNo(value) || mapEnumImpl(shareModes, value, i))
		  &&   SET(ctx->shareMode, uint32(i));
	}
	return false;
}

bool ClaspOptions::validateOptions(const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& vm, Messages& m) {
	if (!applyDefaultConfig(root, vm, m)) { return false; }
	bool ok;
	if (active == clasp) {
		ok = populateThreadConfigs(clasp->ctx().concurrency(), root, vm, m) && applyTesterConfig(m);
		mode.reset(0);
	}
	else {
		// currently we only support 1:1 concurrency between generator and tester
		// but in the future this might change
		ok = populateThreadConfigs(clasp->ctx().concurrency(), root, vm, m);
	}
	search.reset(0);
	return ok && m.error.empty();
}

void ClaspOptions::applyDefaults(Input::Format f) {
	if (f != Input::SMODELS && !satPreParsed) {
		SatElite::SatElite* pre = new SatElite::SatElite();
		pre->options.maxIters = 20;
		pre->options.maxOcc   = 25;
		pre->options.maxTime  = 120;
		clasp->setSatPrepro(pre);
	}
}
const char* ClaspOptions::getInputDefaults(Input::Format f) const {
	if (f == Input::SMODELS) { return "--eq=5"; }
	else                     { return "--sat-prepro=20,25,120"; }
}
bool ClaspOptions::applyDefaultConfig(const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& vm, ProgramOptions::Messages& m) { 
	// check if command-line is valid
	bool isGenerator = active == clasp;
	if ((isGenerator && !mode->validateOptions(root, vm, m)) || !search->validateOptions(root, vm, m)) { return false; }
	OptionConfig def(defConfig);
	if (search->config.solver->search == Clasp::SolverStrategies::no_learning) {
		if      (vm.count("configuration") == 0){ def = OptionConfig("[NoLearn]: --heuristic=unit"); }
		else if (vm.count("heuristic") == 0)    { removeConfig(def, "heuristic"); def.cmdLine.append(" --heuristic=unit"); }
	}
	uint32 delSched = search->config.search->reduce.strategy.scheds;
	if (vm.count("deletion") && delSched != ReduceStrategy::sched_both) {
		if ((delSched & ReduceStrategy::sched_grow) == 0) { removeConfig(def, "del-grow"); }
		if ((delSched & ReduceStrategy::sched_cfl) == 0)  { removeConfig(def, "del-cfl");  }
	}
	// all from command line
	ProgramOptions::ParsedOptions parsed(vm);
	// add options from selected default config
	parsed.assign(ProgramOptions::parseCommandString(def.cmdLine, root, !isGenerator));
	if (isGenerator) {
		satPreParsed = parsed.count("sat-prepro") != 0;
		clasp->setConcurrency(mode->config->ctx.concurrency());
		if (vm.count("opt-heuristic") == 0) {
			for (uint32 i = 1; i != mode->config->ctx.concurrency(); ++i) {
				clasp->addSolver(i).optHeu |= (i & 3u);
			}
		}
	}
	return search->validateOptions(root, parsed, m);
}
void ClaspOptions::removeConfig(OptionConfig& cfg, const char* opt) const {
	typedef std::string::size_type pos_type;
	pos_type pos = cfg.cmdLine.find(opt);
	if (pos != std::string::npos) {
		cfg.cmdLine.erase(pos-2, cfg.cmdLine.find("--", pos) - (pos-2));
	}
}

bool ClaspOptions::applyTesterConfig(Messages& m) {
	if (testerOpts.empty() && mode->config->ctx.concurrency() < 2) { return true; }
	OptionContext testerRoot;
	this->active = clasp->addTesterConfig();
	initCommandOptions(testerRoot);
	initSearchOptions(testerRoot);
	try {
		ParsedOptions parsed;
		parsed.assign(parseCommandString(testerOpts, testerRoot));
		testerRoot.assignDefaults(parsed);
		if (!validateOptions(testerRoot, parsed, m)) {
			throw std::runtime_error(m.error);
		}
	} catch (const std::exception& e) {
		m.error  = "In <tester>: ";
		m.error += e.what();
		return false;
	}
	return true;
}

#define DEF_SOLVE    "--heuristic=Berkmin --restarts=x,100,1.5 --deletion=1,75 --del-init-r=200,40000 --del-max=400000 --del-algo=basic --contraction=250 --loops=common --save-p=180"
#define FRUMPY_SOLVE DEF_SOLVE " --del-grow=1.1 --strengthen=local --disj-true"
#define JUMPY_SOLVE  "--heuristic=Vsids --restarts=L,100 --del-init-r=1000,20000 --del-algo=basic,2 --deletion=3,75 --del-grow=1.1,25,x,100,1.5 --del-cfl=x,10000,1.1 --del-glue=2 --update-lbd=3 --strengthen=recursive --otfs=2 --save-p=70"
#define HANDY_SOLVE  "--heuristic=Vsids --restarts=D,100,0.7 --deletion=2,50,20.0 --del-max=200000 --del-algo=sort,2 --del-init-r=1000,14000 --del-cfl=+,4000,600 --del-glue=2 --update-lbd --strengthen=recursive --otfs=2 --save-p=20 --contraction=600 --loops=distinct --counter-restarts=7 --counter-bump=1023 --reverse-arcs=2"
#define CRAFTY_SOLVE "--heuristic=Vsids --restarts=x,128,1.5 --deletion=3,75,10.0 --del-init-r=1000,9000 --del-grow=1.1,20.0 --del-cfl=+,10000,1000 --del-algo=basic --del-glue=2 --otfs=2 --reverse-arcs=1 --counter-restarts=3 --contraction=250"
#define TRENDY_SOLVE "--heuristic=Vsids --restarts=D,100,0.7 --deletion=3,50 --del-init=500,19500 --del-grow=1.1,20.0,x,100,1.5 --del-cfl=+,10000,2000 --del-algo=basic --del-glue=2 --strengthen=recursive --update-lbd --otfs=2 --save-p=75 --counter-restarts=3 --counter-bump=1023 --reverse-arcs=2  --contraction=250 --loops=common"

const char* defConfigs_g = {
	/*...*0*/"[frumpy]: " FRUMPY_SOLVE
	"\0"/*1*/"[jumpy]:  --sat-p=20,25,240,-1,1 --trans-ext=dynamic " JUMPY_SOLVE
	"\0"/*2*/"[handy]:  --sat-p=10,25,240,-1,1 --trans-ext=dynamic --backprop " HANDY_SOLVE
	"\0"/*3*/"[crafty]: --sat-p=10,25,240,-1,1 --trans-ext=dynamic --backprop " CRAFTY_SOLVE " --save-p=180"
	"\0"/*4*/"[trendy]: --sat-p=20,25,240,-1,1 --trans-ext=dynamic " TRENDY_SOLVE
	"\0"
};

const char* portfolio_g = {
	/*     0 */"[CRAFTY]: " CRAFTY_SOLVE " --opt-heu=1"
#if WITH_THREADS
	"\0"/* 1 */"[TRENDY]: " TRENDY_SOLVE " --opt-heu=1"
	"\0"/* 2 */"[FRUMPY]: " FRUMPY_SOLVE
	"\0"/* 3 */"[JUMPY]:  " JUMPY_SOLVE " --opt-heu=3"
	"\0"/* 4 */"[STRONG]: " DEF_SOLVE " --berk-max=512 --del-grow=1.1,25 --otfs=2 --reverse-arcs=2 --strengthen=recursive --init-w=2 --lookahead=atom,10"
	"\0"/* 5 */"[HANDY]:  " HANDY_SOLVE
	"\0"/* 6 */"[S2]: --heuristic=Vsids --reverse-arcs=1 --otfs=1 --local-restarts --save-progress=0 --contraction=250 --counter-restart=7 --counter-bump=200 --restarts=x,100,1.5 --del-init=800,-1 --del-algo=basic,0 --deletion=3,60 --strengthen=local --del-grow=1.0,1.0 --del-glue=4 --del-cfl=+,4000,300,100"
	"\0"/* 7 */"[S4]: --heuristic=Vsids --restarts=L,256 --counter-restart=3 --strengthen=recursive --update-lbd --del-glue=2 --otfs=2 --del-algo=inp_sort,2 --deletion=1,75,20 --del-init=1000,19000"
	"\0"/* 8 */"[SLOW]:  --heuristic=Berkmin --berk-max=512 --restarts=F,16000 --lookahead=atom,50"
	"\0"/* 9 */"[VMTF]:  --heu=VMTF --str=no --contr=0 --restarts=x,100,1.3 --del-init-r=800,9200"
	"\0"/* 10 */"[SIMPLE]:  --heu=VSIDS  --strengthen=recursive --restarts=x,100,1.5,15 --contraction=0"
	"\0"/* 11*/"[LUBY-SP]: --heu=VSIDS --restarts=L,128 --save-p --otfs=1 --init-w=2 --contr=0 --opt-heu=3"
	"\0"/* 12 */"[LOCAL-R]: --berk-max=512 --restarts=x,100,1.5,6 --local-restarts --init-w=2 --contr=0"
#endif
	"\0"
};

/////////////////////////////////////////////////////////////////////////////////////////
// clasp multi-threading
/////////////////////////////////////////////////////////////////////////////////////////
#if WITH_THREADS
const EnumMap intFilters[] = {
	{"all", SolveOptions::Integration::filter_no}, {"gp", SolveOptions::Integration::filter_gp},
	{"unsat", SolveOptions::Integration::filter_sat}, {"active", SolveOptions::Integration::filter_heuristic},
	{0,0}
};
const EnumMap topoMap[] = {
	{"all", SolveOptions::Integration::topo_all}, {"ring", SolveOptions::Integration::topo_ring},
	{"cube", SolveOptions::Integration::topo_cube}, {"cubex", SolveOptions::Integration::topo_cubex},
	{0,0}
};
const EnumMap distMap[] = {
	{"all", Constraint_t::learnt_conflict | Constraint_t::learnt_loop}, {"short", Constraint_t::max_value+1}, 
	{"conflict", Constraint_t::learnt_conflict}, {"loop", Constraint_t::learnt_loop},
	{0,0}
};

void ModeOptions::addSolveOptions(ProgramOptions::OptionGroup& root) {
	root.addOptions() 
		("parallel-mode,t", notify(this, &ModeOptions::mapSolveOpts),
		  "Run parallel search with given number of threads\n"
			"      %A: <n {1..64}>[,<mode {compete|split}>]\n"
			"        <n>   : Number of threads to use in search\n"
			"        <mode>: Run competition or splitting based search [compete]\n")

		("global-restarts,@1", notify(this, &ModeOptions::mapSolveOpts)->implicit("5")->arg("<X>"),
		 "Configure global restart policy\n"
		 "      %A: <n>[,<sched>] / Implicit: %I\n"
		 "        <n> : Maximal number of global restarts (0=disable)\n"
		 "     <sched>: Restart schedule [x,100,1.5] (<type {F|L|x|+}>)\n")
	 
		("distribute!,@1", notify(this, &ModeOptions::mapSolveOpts)->defaultsTo("conflict,4"),
		 "Configure nogood distribution [%D]\n"
		 "      %A: <type>[,<lbd {0..127}>][,<size>]\n"
		 "        <type> : Distribute {all|short|conflict|loop} nogoods\n"
		 "        <lbd>  : Distribute only if LBD  <= <lbd>  [4]\n"
		 "        <size> : Distribute only if size <= <size> [-1]")
		("integrate,@1", notify(this, &ModeOptions::mapSolveOpts)->defaultsTo("gp")->state(Value::value_defaulted),
		 "Configure nogood integration [%D]\n"
		 "      %A: <pick>[,<n>][,<topo>]\n"
		 "        <pick>: Add {all|unsat|gp(unsat wrt guiding path)|active} nogoods\n"
		 "        <n>   : Always keep at least last <n> integrated nogoods   [1024]\n"
		 "        <topo>: Accept nogoods from {all|ring|cube|cubex} peers    [all]\n")
	;
}
bool ModeOptions::mapSolveOpts(ModeOptions* this_, const std::string& key, const std::string& value) {
	SolveOptions* thread = &this_->config->solve;
	if (key == "parallel-mode") {
		std::pair<uint32, std::string> x;
		if      (!parse(value, x) || x.first < 1 || x.first > SolveOptions::supportedSolvers()) { return false; }
		else if (x.second == "compete" || x.second.empty()) { thread->mode = SolveOptions::mode_compete; }
		else if (x.second == "split")                       { thread->mode = SolveOptions::mode_split;   }
		else return false;
		this_->config->ctx.concurrency(x.first);
	}
	else if (key == "distribute") {
		std::pair<std::string, std::pair<uint32, uint32> > parsed("", std::make_pair(4, UINT32_MAX));
		int typeMask = 0;
		if      (isFlagNo(value))                               { parsed.second = std::make_pair(0,0); }
		else if (!parse(value, parsed))                         { return false; }
		else if (!mapEnumImpl(distMap, parsed.first, typeMask)) { return false; }
		else if (parsed.second.first > Activity::MAX_LBD)       { return false; }
		this_->config->ctx.options().setDistribution(parsed.second.second, parsed.second.first, (uint32)typeMask);
	}
	else if (key == "integrate") {
		std::pair<std::string, std::pair<uint32, std::string> > parsed("", std::make_pair(1024, "all"));
		int i, j;
		if      (!parse(value, parsed))                            return false;
		else if (!mapEnumImpl(intFilters, parsed.first, i))        return false;
		else if (!mapEnumImpl(topoMap, parsed.second.second, j))   return false;
		thread->integrate.filter = static_cast<SolveOptions::Integration::Filter>(i);
		thread->integrate.topo   = static_cast<SolveOptions::Integration::Topology>(j);
		SET_OR_FILL(thread->integrate.grace, parsed.second.first);
	}
	else if (key == "global-restarts") {
		std::pair<uint32, ScheduleStrategy> arg;
		if (!parse(value, arg) || arg.second.type == ScheduleStrategy::user_schedule) { return false; }
		thread->restarts.maxR  = arg.first;
		thread->restarts.sched = arg.second;
	}
	else { throw std::logic_error(std::string("Key not checked: ")+key); }
	return true;
}
const char* ClaspOptions::loadPortfolio(const std::string& fn, std::string& mem) {
	std::ifstream file(fn.c_str());
	if (!file) {
		mem = "Could not open portfolio file '";
		mem += fn;
		mem += "'";
		throw std::runtime_error(mem);
	}
	mem.clear();
	mem.reserve(128);
	for (std::string line; std::getline(file, line); ) {
		if (line.empty() || line[0] == '#') { continue; }
		mem += line;
		mem += '\0';
	}
	mem += '\0';
	return mem.data();
}

void ClaspOptions::addMtCtxOptions(ProgramOptions::OptionGroup& root) {
	portfolio   = "";
	root.setDescriptionLevel(ProgramOptions::desc_level_default);
	root.addOptions()
		("share!,@1", notify(this, &ClaspOptions::mapCtxOpts)->defaultsTo("all"), 
		 "Configure physical sharing of constraints [%D]\n"
		 "      %A: {problem|learnt|all}\n")
		("portfolio!,p", storeTo(portfolio), "Use portfolio to configure solver(s)\n"
		 "      %A: {default|seed|<file>}")
		("print-portfolio,g" , flag(genTemplate), "Print default portfolio and exit\n")
	;
}

bool ClaspOptions::populateThreadConfigs(uint32 num, const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& vm, Messages& m) {
	if (portfolio.empty() && mode->config->solve.mode == SolveOptions::mode_compete) {
		portfolio = "default";
	}
	if (num <= 1 || portfolio.empty() || portfolio == "no") { return true; }
	RNG r;
	if (portfolio == "seed") {
		for (uint32 i = 1; i != num; ++i) { active->addSolver(i).rng.srand(r.rand()); }
		return true;
	}
	std::string mem;
	const char* port = portfolio == "default" ? portfolio_g : loadPortfolio(portfolio, mem);
	bool addSeed     = false;
	const char* p    = port;
	uint32 i         = 0;
	OptionContext local;
	// we init the master last so that
	// client options are cloned from the command-line + defaults
	do {
		p += (strlen(p) + 1);
		if (++i == num || !*p) { p = port; addSeed = i != num; i %= num; }
		SearchOptions::SolverConfig sc(active->addSolver(i), active->addSearch(i));
		search->initOptions(root, local, sc);
		OptionConfig cmd(p);
		if (!applySearchConfig(local, cmd, vm, m)) { return false; }
		if (addSeed) { search->config.solver->rng.srand(r.rand()); }
	} while (i != 0);
	return true;
}

bool ClaspOptions::applySearchConfig(const OptionContext& ctx, const OptionConfig& c, const ProgramOptions::ParsedOptions& vm, Messages& m) {
	try {
		// all from command-line
		ProgramOptions::ParsedOptions parsed(vm);
		// all from current config
		parsed.assign(ProgramOptions::parseCommandString(c.cmdLine, ctx));
		if (!search->validateOptions(ctx, parsed, m)) { throw std::logic_error(m.error); }
		return true;
	}
	catch(const std::exception& e) {
		std::string err("In [");
		err += c.name;
		err += "]: ";
		err += e.what();
		m.error = err;
		return false;
	}
}
#else
void ModeOptions::addSolveOptions(ProgramOptions::OptionGroup&) {}
bool ModeOptions::mapSolveOpts(ModeOptions*, const std::string&, const std::string&) { return false; }
bool ClaspOptions::populateThreadConfigs(uint32, const ProgramOptions::OptionContext&, const ProgramOptions::ParsedOptions&, Messages&) { return true; }
void ClaspOptions::addMtCtxOptions(ProgramOptions::OptionGroup&) {}
#endif
#undef SET
#undef SET_LEQ
#undef SET_OR_FILL
#undef SET_OR_ZERO
#undef SET_R
#undef SWITCH
#undef CASE
}
