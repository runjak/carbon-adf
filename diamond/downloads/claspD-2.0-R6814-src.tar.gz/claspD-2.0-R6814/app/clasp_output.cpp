// 
// Copyright (c) 2009-2012, Benjamin Kaufmann
// 
// This file is part of Clasp. See http://www.cs.uni-potsdam.de/clasp/ 
// 
// Clasp is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// Clasp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Clasp; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//
#include "clasp_output.h"
#include "alarm.h" // for SIGALRM
#include <clasp/clasp_facade.h>
#include <clasp/minimize_constraint.h>
#include <clasp/satelite.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <climits>

namespace Clasp { namespace {
inline std::string prettify(const std::string& str) {
	if (str.size() < 40) return str;
	std::string t("...");
	t.append(str.end()-38, str.end());
	return t;
}}
/////////////////////////////////////////////////////////////////////////////////////////
// RunSummary and OutputFormat
/////////////////////////////////////////////////////////////////////////////////////////
OutputFormat::RunSummary::Result OutputFormat::RunSummary::result() const {
	uint64 m  = enumerator.enumerated;
	Result r  = result_unknown;
	if (m != 0) { // SAT
		if (!enumerator.minimize()){ r = result_sat; }
		else if (complete())       { r = result_optimum; }
		else                       { r = result_sat_opt; }
	}
	else if (complete()) { r = result_unsat; }
	return r;
}

int OutputFormat::RunSummary::exitCode() const {
	uint64 m            = enumerator.enumerated;
	int   ec            = 0;
	if (termSig()) { ec|= E_INTERRUPT; }
	if (m != 0)    { ec|= E_SAT; }
	if (complete()){ ec|= E_EXHAUST; }
	return ec;
}

uint64 OutputFormat::RunSummary::models() const {
	return (enumerator.enumerated == 0 || !(enumerator.optimize()||consequences)) ? enumerator.enumerated : 1;
}

OutputFormat::OutputFormat(uint32 verbosity) : curr_(0), next_(0), lpStats_(0), verbosity_(0), quiet_(0) {
	result[RunSummary::result_unknown] = "UNKNOWN";
	result[RunSummary::result_unsat]   = "UNSATISFIABLE";
	result[RunSummary::result_sat]     = "SATISFIABLE";
	result[RunSummary::result_optimum] = "OPTIMUM FOUND";
	result[RunSummary::result_sat_opt] = "SATISFIABLE";
	verbosity_ = (int)std::min(verbosity, (uint32)INT_MAX);
}
OutputFormat::~OutputFormat() {
	delete lpStats_;
}
void OutputFormat::initSolve(const Solver& s, ProgramBuilder* api) {
	// grab the stats_ so that we can later print them
	if (api) {
		if (!lpStats_) lpStats_ = new PreproStats;
		lpStats_->accu(api->stats);
	}
	saved_.resize(2*s.assignment().numVars());
	curr_ = 0;
	next_ = &saved_[0];
}

void OutputFormat::reportModel(const Solver& s, const Enumerator& en) {
	// remember current (tentative) model
	if (modelQ() < print_no) {
		Model m = storeModel(s.assignment());
		if (modelQ() == print_all) {
			// fire & forget: just output the model
			curr_ = 0;
			printModel(m, s.sharedContext()->symTab(), en);
		}
	}
	reportOptimize(en, print_all);
}

void OutputFormat::reportConsequences(const Solver& s, const Enumerator& en, const char* cbType) {
	if (modelQ() == print_all) {
		printConsequences(s.sharedContext()->symTab(), en, cbType);
	}
	else if (modelQ() == print_best) {
		curr_ = &saved_[0];
	}
	reportOptimize(en, print_all);
}

void OutputFormat::reportResult(const RunSummary& sol, const SolveStats* accu, bool more) {
	const Enumerator& en = sol.enumerator;
	if (curr_ != 0) {
		// print saved model
		if (sol.consequences) {
			printConsequences(sol.ctx.symTab(), en, sol.consequences);
		}
		else {
			Model m(curr_, curr_ > next_ ? static_cast<uint32>(curr_ - next_) : static_cast<uint32>(next_ - curr_));
			printModel(m, sol.ctx.symTab(), en);
		}
	}
	if (en.enumerated > 0 && optQ() == print_best) {
		reportOptimize(en, print_best);
	}
	printSolution(sol.result());
	if (verbosity() > 0 || accu) {
		printSummary(sol);
	}
	if (accu != 0) {
		reportStats(sol, *accu, more);	
	}
	printFooter();
}

void OutputFormat::reportOptimize(const Enumerator& en, PrintLevel printLevel) {
	if (en.minimize() && optQ() == printLevel) {
		printOptimize(*en.minimize());
	}
}

OutputFormat::Model OutputFormat::storeModel(const Assignment& a) {
	assert(saved_.size() == 2*a.numVars());
	ValueRep* x= next_;
	for (Var v = 0, end = a.numVars(); v != end; ++v) {
		*x++ = a.value(v);
	}
	curr_      = next_;
	next_      = curr_ == &saved_[0] ? x : &saved_[0];
	return Model(curr_, curr_ > next_ ? static_cast<uint32>(curr_ - next_) : static_cast<uint32>(next_ - curr_));
}
void OutputFormat::reportStats(const RunSummary& sol, const SolveStats& stats, bool more) {
	startObject("Stats", type_object);
	const ProblemStats& pr = sol.ctx.stats();
	printMainStats(stats, true);
	printProblemStats(pr, lpStats());
	if (stats.jumps){ printJumpStats(*stats.jumps, true);}
	if (more && sol.ctx.concurrency() > 1) {
		startObject("Thread", type_array);
		for (uint32 i = 0; i != sol.ctx.concurrency(); ++i) {
			startObject(0, type_object);
			const SolveStats& st = sol.ctx.solver(i)->stats;
			printMainStats(st, false);
			if (st.jumps)    { printJumpStats(*st.jumps, false); }
			endObject(type_object);
		}
		endObject(type_array);
	}
	if (sol.ctx.sccGraph.get() && sol.ctx.sccGraph->numNonHcfs() && more) {
		startObject("NonHcf", type_array);
		for (SharedDependencyGraph::NonHcfIter it = sol.ctx.sccGraph->nonHcfBegin(); it != sol.ctx.sccGraph->nonHcfEnd(); ++it) {
			startObject(0, type_object);
			const SolveStats* accu = it->second->ctx().accuStats(true);
			printProblemStats(it->second->ctx().stats(), 0);
			if (accu) {
				printMainStats(*accu, false);
				if (accu->jumps) { printJumpStats(*accu->jumps, false); }
			}
			endObject(type_object);
		}
		endObject(type_array);
	}
	endObject(type_object);
}
/////////////////////////////////////////////////////////////////////////////////////////
// DefaultOutput
/////////////////////////////////////////////////////////////////////////////////////////
#define printKey(k)                  printf("%s%-*s: ", format_[cat_comment], w_, (k))
#define printKeyValue(k, fmt, value) printf("%s%-*s: " fmt, format_[cat_comment], w_, (k), (value))
const char* const rowSep = "----------------------------------------------------------------------------|";
#define printLN(fmt, ...) \
	printf("%s" fmt "\n", format_[cat_comment], ##__VA_ARGS__)

DefaultOutput::DefaultOutput(uint32 v, const std::pair<uint32,uint32>& q, Format f, char ifs)
	: OutputFormat(v)
	, prepro_(0)
	, as_(0)
	, eom_(0)
	, arr_(0)
	, obj_(0)
	, header_(INT_MIN)
	, IFS_(ifs) {
	ev_ = 0;
	configureFormat(f, q, ifs);
}

DefaultOutput::~DefaultOutput() {
	free((void*)as_);
	free((void*)eom_);
}

// sets up format strings and configures verbosity and quiet levels
void DefaultOutput::configureFormat(Format f, PrintPair q, char ifs) {
	format_[cat_comment]   = "";
	format_[cat_value]     = "";
	format_[cat_objective] = "Optimization: ";
	format_[cat_result]    = "";
	format_[cat_value_term]= "";
	format_[cat_atom_pre]  = "";
	format_[cat_atom_post] = "";
	if (f == format_aspcomp) {
		format_[cat_comment]   = "% ";
		format_[cat_value]     = "ANSWER\n";
		format_[cat_objective] = "COST ";
		format_[cat_atom_post] = ".";
		result[RunSummary::result_sat]     = "";
		result[RunSummary::result_sat_opt] = "";
		result[RunSummary::result_unsat]   = "INCONSISTENT";
		result[RunSummary::result_optimum] = "OPTIMUM";
		if (q.first == uint32(print_f_default)) {
			q.first = print_best;
		}
		if (q.second == uint32(print_f_default)) {
			q.second= q.first;
		}
	}
	else if (f == format_sat09 || f == format_pb09) {
		format_[cat_comment]   = "c ";
		format_[cat_value]     = "v ";
		format_[cat_objective] = "o ";
		format_[cat_result]    = "s ";
		format_[cat_value_term]= "0";
		if (f == format_pb09) {
			format_[cat_value_term]= "";
			format_[cat_atom_pre]  = "x";
			if (q.first == uint32(print_f_default)) {
				q.first = print_best;
			}
		}
	}
	setQuiet(q);
	free((void*)as_);
	free((void*)eom_);
	if ( (IFS_=ifs) != '\n') {
		char t[2] = { IFS_, '\0' };
		as_       = strdup(t);
	}
	else {
		char* temp= (char*)malloc(strlen(format_[cat_value])+2);
		temp[0]   = IFS_;
		temp[1]   = '\0';
		temp      = strcat(temp, format_[cat_value]);
		as_       = temp;
	}
	if (strcmp(format_[cat_value_term], "") == 0) {
		eom_ = strdup("\n");
	}
	else {
		char* temp = (char*)malloc(strlen(as_)+strlen(format_[cat_value_term])+2);
		temp       = strcpy(temp, as_);
		temp       = strcat(temp, format_[cat_value_term]);
		temp       = strcat(temp, "\n");
		eom_       = temp;
	}
	w_ = 13+(int)strlen(format_[cat_comment]);
}

void DefaultOutput::comment(int v, const char* fmt, ...) const {
	if (verbosity() >= v) {
		printf("%s", format_[cat_comment]);
		va_list args;
		va_start(args, fmt);
		vfprintf(stdout, fmt, args);
		va_end(args);
		fflush(stdout);
	}
}	

void DefaultOutput::reportProgress(const PreprocessEvent& e) {
	if (e.type == (int)SatElite::SatElite::event_type && verbosity() >= 2) {
		const SatElite::SatElite::Event& ev = static_cast<const SatElite::SatElite::Event&>(e);
		printf("\r");
		if (ev.op != '*' || ev.cur != ev.max) { comment(2, "Preprocessing: %c: %8u/%-8u", ev.op, ev.cur, ev.max); }
		else                                  { comment(2, "Preprocessing: "); prepro_ = ev.self; }
	}
}

void DefaultOutput::reportProgress(const SolveEvent& e) {
	int v = header_ != INT_MIN ? verbosity() : 0;
	if (v < 2 || e.type > v || (e.type > 2 && (e.type & v) == 0)) { return; }
	int last = ev_.fetch_and_store(e.type);
	if (e.type < SolveEvent_t::progress_path) {
		if (last >= SolveEvent_t::progress_path)    { printLN("%s", rowSep);  }
		if (e.type == SolveEvent_t::progress_state) {
			const SolveStateEvent& ev = static_cast<const SolveStateEvent&>(e);
			if (ev.time < 0) { printLN("%02u:S| %-15s %-53s |", e.solver->id(), "ENTERING", ev.state); }
			else             { printLN("%02u:S| %-15s %-33s after %12.3fs |", e.solver->id(), "LEAVING", ev.state, ev.time); }
		}
		else if (e.type == SolveEvent_t::progress_msg) { printLN("%02u:G| %-69s |", e.solver->id(), static_cast<const SolveMsgEvent&>(e).msg); }
	}
	else if (e.type == SolveEvent_t::progress_path || e.type == SolveEvent_t::progress_test) {
		if      (--header_ == 0)                     { printSolveHeader();  }
		else if (last < SolveEvent_t::progress_path) { printLN("%s", rowSep);  }
		const Solver& s = *e.solver;
		uint32 fixed    = s.decisionLevel() > 0 ? s.levelStart(1) : s.numAssignedVars();
		if (e.type == SolveEvent_t::progress_path) {
			const SolvePathEvent& ev = static_cast<const SolvePathEvent&>(e);
			printLN("%02u:%c|%7u/%-7u|%8u/%-8u|%10" PRIu64"/%-6.3f|%8" PRId64"/%-10" PRId64"|"
				, s.id()
				, static_cast<char>(ev.evType)
				, s.numFreeVars()
				, fixed
				, s.numConstraints()
				, s.numLearntConstraints()
				, s.stats.conflicts
				, s.stats.conflicts/std::max(1.0,double(s.stats.choices))
				, ev.cLimit <= (UINT32_MAX) ? (int64)ev.cLimit:-1
				, ev.lLimit != (UINT32_MAX) ? (int64)ev.lLimit:-1
			);
		}
		else if (e.type == SolveEvent_t::progress_test) {
			const SolveTestEvent& ev = static_cast<const SolveTestEvent&>(e);
			char ct = ev.partial ? 'P' : 'F';
			if (ev.result == -1) {
				printf("%s%02u:%c| HC: %-5u %-60s|\r", format_[cat_comment], s.id(), ct, ev.scc, "...");
			}
			else {
				printLN("%02u:%c| HC: %-5u %-4s|%8u/%-8u|%10" PRIu64"/%-6.3f| T: %-15.3f|", s.id(), ct, ev.scc, (ev.result == 1 ? "OK" : "FAIL")
					, s.numConstraints()
					, s.numLearntConstraints()
					, ev.conflicts()
					, ev.conflicts()/std::max(1.0,double(ev.choices()))
					, ev.time
				);
			}
		}
	}
	else { ev_ = last; }
	fflush(stdout);
}

void DefaultOutput::reportState(int state, bool enter, double time) {
	if (enter && verbosity()) {
		if (state == ClaspFacade::state_start) {
			if (!solver().empty()) comment(1, "%s\n", solver().c_str());
			if (!input().empty())  comment(1, "Reading from %s\n", prettify(input()).c_str());
		}
		else if (state == ClaspFacade::state_read) {
			comment(2, "Reading      : ");
		}
		else if (state == ClaspFacade::state_preprocess) {
			comment(2, "Preprocessing: ");
		}
		else if (state == ClaspFacade::state_solve) {
			if (verbosity() > 1) { 
				printLN("%s", rowSep);
				printLN("%-76s|", "Solving...");
				printSolveHeader(); 
			}
			else                 { comment(1, "Solving...\n"); }
		}
	}
	else if (!enter && verbosity() > 1) {
		if (state == ClaspFacade::state_read || state == ClaspFacade::state_preprocess) {
			printf("%.3f", time);
			if (prepro_ != 0) { printf(" (ClRemoved: %u ClAdded: %u LitsStr: %u)", prepro_->stats.clRemoved, prepro_->stats.clAdded, prepro_->stats.litsRemoved); }
			printf("\n");
		}
		else if (state == ClaspFacade::state_solve) { printLN("%s", rowSep); } 
	}
}	

void DefaultOutput::printSolveHeader() {
	header_ = 20;
	printf("%s%s\n"
		"%sID:T       Vars           Constraints         State            Limits       |\n"
		"%s       #free/#fixed   #problem/#learnt  #conflicts/ratio #conflict/#learnt  |\n"
		"%s%s\n", 
		format_[cat_comment], rowSep, format_[cat_comment], format_[cat_comment], format_[cat_comment], rowSep
	);
}

void DefaultOutput::printModel(const Model& m, const SymbolTable& index, const Enumerator& en) {
	comment(1, "Answer: %" PRIu64"\n", en.enumerated);
	printf("%s", format_[cat_value]);
	const char* sep = "";
	if (index.type() == SymbolTable::map_indirect) {
		for (SymbolTable::const_iterator it = index.begin(); it != index.end(); ++it) {
			if (m.value(it->second.lit.var()) == trueValue(it->second.lit) && !it->second.name.empty()) {
				printf("%s%s%s%s", sep, format_[cat_atom_pre], it->second.name.c_str(), format_[cat_atom_post]);
				sep = as_;
			}	
		}
	}
	else {
		uint32 const maxLineLen = 70;
		uint32       printed    = 0;
		for (Var v = 1; v < index.size(); ++v) {
			printed += printf("%s%s%s%u%s", sep, m.value(v) == value_false ? "-":"", format_[cat_atom_pre], v, format_[cat_atom_post]);
			sep      = as_;
			if (printed >= maxLineLen && IFS_ != '\n') {
				printed = 0;
				sep     = "";
				printf("\n%s", format_[cat_value]);
			}
		}
	}
	printExtendedModel(m);
	printf("%s", eom_);
	fflush(stdout);
}

void DefaultOutput::printConsequences(const SymbolTable& index, const Enumerator&, const char* cbType) {
	comment(1, "%s consequences:\n", cbType);
	printf("%s", format_[cat_value]);
	const char* sep = "";
	for (SymbolTable::const_iterator it = index.begin(); it != index.end(); ++it) {
		if (it->second.lit.watched()) {
			printf("%s%s%s%s", sep, format_[cat_atom_pre], it->second.name.c_str(), format_[cat_atom_post]);
			sep = as_;
		}
	}
	printf("%s", eom_);
	fflush(stdout);
}
void DefaultOutput::printOptimize(const SharedMinimizeData& m) {
	printf("%s", format_[cat_objective]);
	printOptimizeValues(m);
	printf("\n");
	fflush(stdout);
}

void DefaultOutput::printOptimizeValues(const SharedMinimizeData& m) const {
	const SharedMinimizeData::SumVec& opt = m.optimum()->opt;
	const char* sep = "";
	printf("%s%" PRId64, sep, opt[0]);
	sep = IFS_ != '\n' ? as_ : " ";
	for (uint32 i = 1, end = m.numRules(); i != end; ++i) {
		printf("%s%" PRId64, sep, opt[i]);
	}
}

void DefaultOutput::printSolution(RunSummary::Result r) {
	if (strcmp(result[r], "") != 0) {
		printf("%s%s\n", format_[cat_result], result[r]);
	}
}

void DefaultOutput::printSummary(const RunSummary& sol) {
	printLN("");
	int sig = sol.termSig();
	if      (sig == SIGALRM){ printKeyValue("TIME LIMIT", "%d\n", 1); }
	else if (sig)           { printKeyValue("INTERRUPTED", "%d\n", 1);}
	const Enumerator& en = sol.enumerator;
	printKey("Models");
	if (!sol.complete()) {
		char buf[64];
		int wr    = sprintf(buf, "%" PRIu64, sol.models());
		buf[wr]   = '+';
		buf[wr+1] = 0;
		printf("%-6s\n", buf);
	}
	else { printf("%-6" PRIu64"\n", sol.models()); }
	if (en.enumerated) {
		if (en.enumerated != sol.models()) { 
			printKeyValue("  Enumerated", "%" PRIu64"\n", en.enumerated);
		}
		if (sol.consequences) {
			printf("%s  %-*s: %s\n", format_[cat_comment], w_-2, sol.consequences, sol.complete()?"yes":"unknown");
		}
		if (en.minimize()) {
			printKeyValue("  Optimum", "%s\n", sol.complete()?"yes":"unknown");
			if (en.optimize()) {
				printKey("Optimization");
				printOptimizeValues(*en.minimize());
			}
			printf("\n");
		}
	}
	printKey("Time");
	printf("%.3fs (Solving: %.2fs 1st Model: %.2fs Unsat: %.2fs)\n"
			, sol.totalTime
			, sol.solveTime
			, sol.modelTime
			, sol.unsatTime);
	printKeyValue("CPU Time", "%.3fs\n", sol.cpuTime);
	if (sol.ctx.concurrency() > 1) {
		printKeyValue("Threads", "%-6u", sol.ctx.concurrency());
		printf(" (Winner: %u)\n", sol.ctx.winner());
	}
}

void DefaultOutput::printMainStats(const SolveStats& st, bool accu) {
	printLN("");
	if (!accu && st.extra) {
		printKeyValue("CPU Time",  "%.3fs\n", st.extra->cpuTime);
		printKeyValue("Models", "%" PRIu64"\n", st.extra->models);
	}
	printKeyValue("Choices", "%" PRIu64"\n", st.choices);
	printKeyValue("Conflicts", "%-6" PRIu64"", st.conflicts);
	printf(" (Analyzed: %" PRIu64")\n", st.backjumps());
	printKeyValue("Restarts", "%-6" PRIu64"", st.restarts);
	if (st.restarts) {
		printf(" (Average: %.2f Last: %" PRIu64")", st.avgRestart(), st.cflLast);
	}
	printf("\n");
	if (!st.extra) { return; }
	const ExtendedStats& stx = *st.extra;
	if (stx.numTests) {
		printKeyValue("Stab. Tests", "%-6" PRIu64, stx.numTests);
		printf(" (Full: %" PRIu64" Partial: %" PRIu64")\n", stx.numTests - stx.numPartial, stx.numPartial);
	}
	if (stx.models) {
		printKeyValue("Model-Level", "%-6.1f\n", stx.avgModel());
	}
	printKeyValue("Problems", "%-6" PRIu64,  (uint64)stx.gps);
	printf(" (Average Length: %.2f Splits: %" PRIu64")\n", stx.avgGp(), (uint64)stx.splits);
	uint64 sum          = stx.sumLemmas();
	printKeyValue("Lemmas", "%-6" PRIu64, sum);
	printf(" (Deleted: %" PRIu64")\n",  stx.deleted);
	const char* names[] = {"  Conflict", "  Loop", "  Other"};
	for (int i = 0; i <= Constraint_t::learnt_other; ++i) {
		if (i == 0) {
			printKeyValue("  Binary", "%-6" PRIu64, uint64(stx.binary));
			printf(" (Ratio: %6.2f%%)\n", percent(stx.binary, sum));
			printKeyValue("  Ternary", "%-6" PRIu64, uint64(stx.ternary));
			printf(" (Ratio: %6.2f%%)\n", percent(stx.ternary, sum));
		}
		else {
			printKeyValue(names[i-1], "%-6" PRIu64, stx.num(ConstraintType(i)));
			printf(" (Average Length: %6.1f Ratio: %6.2f%%) \n", stx.avgLen(ConstraintType(i)), percent(stx.num(ConstraintType(i)), sum));
		}
	}
	if (stx.distributed || stx.integrated) {
		printKeyValue("  Distributed", "%-6" PRIu64, stx.distributed);
		printf(" (Ratio: %6.2f%% Average LBD: %.2f) \n", stx.distRatio()*100.0, stx.avgDistLbd());
		printKeyValue("  Integrated", "%-6" PRIu64, stx.integrated);
		if (accu){ printf(" (Ratio: %6.2f%% ", stx.intRatio()*100.0); }
		else     { printf(" ("); }
		printf("Unit: %" PRIu64" Average Jumps: %.2f)\n", stx.intImps, stx.avgIntJump());
	}	
}

void DefaultOutput::printProblemStats(const ProblemStats& ps, const PreproStats* lp) {
	printLN("");
	if (lp) {
		printKeyValue("Atoms", "%-6u", lp->atoms);
		if (lp->auxAtoms) {
			printf(" (Original: %u Auxiliary: %u)", lp->atoms-lp->auxAtoms, lp->auxAtoms);
		}
		printf("\n");
		printKeyValue("Rules", "%-6u", lp->sumRules());
		printf(" ");
		char space = '(';
		for (RuleType i = BASICRULE; i != ENDRULE; ++i) {
			PreproStats::RPair r = lp->rules(i);
			if (r.first) {
				printf("%c%d: %u", space, i, r.first);
				if (lp->tr()) { printf("/%u", r.second); }
			}
			space = ' ';
		}
		printf(")\n");
		printKeyValue("Bodies", "%-6u\n", lp->bodies);
		if (lp->sumEqs() > 0) {
			printKeyValue("Equivalences", "%-6u", lp->sumEqs());
			printf(" (Atom=Atom: %u Body=Body: %u Other: %u)\n" 
				, lp->numEqs(Var_t::atom_var)
				, lp->numEqs(Var_t::body_var)
				, lp->numEqs(Var_t::atom_body_var));
		}
		printKey("Tight");
		if      (lp->sccs == 0)              { printf("Yes"); }
		else if (lp->sccs != PrgNode::noScc) { printf("%-6s (SCCs: %u Non-Hcfs: %u Nodes: %u Gammas: %u)", "No", lp->sccs, lp->nonHcfs, lp->ufsNodes, lp->gammas); }
		else                                 { printf("N/A"); }
		printf("\n");
	}
	uint32 sum = ps.constraints + ps.constraints_binary + ps.constraints_ternary;
	printKeyValue("Variables", "%-6u", ps.vars);
	printf(" (Eliminated: %4u Frozen: %4u)\n", ps.vars_eliminated, ps.vars_frozen);
	printKeyValue("Constraints", "%-6u", sum);
	printf(" (Binary:%5.1f%% Ternary:%5.1f%% Other:%5.1f%%)\n"
		, percent(ps.constraints_binary, sum)
		, percent(ps.constraints_ternary, sum)
		, percent(ps.constraints, sum));
}

void DefaultOutput::printJumpStats(const JumpStats& st, bool) {
	printLN("");
	printKeyValue("Backjumps", "%-6" PRIu64, st.jumps);
	printf(" (Average: %5.2f Max: %3u Sum: %6" PRIu64")\n", st.avgJump(), st.maxJump, st.jumpSum);
	printKeyValue("  Executed", "%-6" PRIu64, st.jumps-st.bJumps);
	printf(" (Average: %5.2f Max: %3u Sum: %6" PRIu64" Ratio: %6.2f%%)\n", st.avgJumpEx(), st.maxJumpEx, st.jumped(), st.jumpedRatio()*100.0);
	printKeyValue("  Bounded", "%-6" PRIu64, st.bJumps);
	printf(" (Average: %5.2f Max: %3u Sum: %6" PRIu64" Ratio: %6.2f%%)\n", st.avgBound(), st.maxBound, st.boundSum, 100.0 - (st.jumpedRatio()*100.0));
}
void DefaultOutput::startObject(const char* k, ObjType t) {
	if (t == type_array) {
		arr_ = k ? k : "Array";
		printLN("");
		printLN("============ %s Stats ============", arr_);
		printLN("");
		obj_ = 0;
	}
	else if (arr_) {
		printLN("[%s %d]", arr_, obj_++);
	}
}
void DefaultOutput::endObject(ObjType t) {
	if (t == type_array) {
		arr_ = 0;
		obj_ = 0;
	}
	else { printLN(""); }
}
void DefaultOutput::printFooter() { fflush(stdout); }
#undef printKeyValue
#undef printKey
#undef printLN
/////////////////////////////////////////////////////////////////////////////////////////
// JsonOutput
/////////////////////////////////////////////////////////////////////////////////////////
JsonOutput::JsonOutput(uint32 v, const std::pair<uint32,uint32>& q) : OutputFormat(v), indent_(0), open_(""), hasModel_(false), hasWitness_(false) {
	setQuiet(q);
}

void JsonOutput::printKey(const char* k) {
	printf("%s%-*s\"%s\": ", open_, indent_, " ", k);
	open_ = ",\n";
}

void JsonOutput::printString(const char* v, const char* sep) {
	assert(v);
	const uint32 BUF_SIZE = 1024;
	char buf[BUF_SIZE];
	uint32 n = 0;
	buf[n++] = '"';
	while (*v) {
		if      (*v != '\\' && *v != '"')                       { buf[n++] = *v++; }
		else if (*v == '"' || !strchr("\"\\/\b\f\n\r\t", v[1])) { buf[n++] = '\\'; buf[n++] = *v++; }
		else                                                    { buf[n++] = v[0]; buf[n++] = v[1]; v += 2; }
		if (n > BUF_SIZE - 2) { buf[n] = 0; printf("%s%s", sep, buf); n = 0; sep = ""; }
	}
	buf[n] = 0;
	printf("%s%s\"", sep, buf);
}

void JsonOutput::printKeyValue(const char* k, const char* v) {
	printf("%s%-*s\"%s\": ", open_, indent_, " ", k);
	printString(v,"");
	open_ = ",\n";
}
void JsonOutput::printKeyValue(const char* k, uint64 v) {
	printf("%s%-*s\"%s\": %" PRIu64, open_, indent_, " ", k, v);
	open_ = ",\n";
}
void JsonOutput::printKeyValue(const char* k, uint32 v) { return printKeyValue(k, uint64(v)); }
void JsonOutput::printKeyValue(const char* k, double v) {
	printf("%s%-*s\"%s\": %.3f", open_, indent_, " ", k, v);
	open_ = ",\n";
}

void JsonOutput::startObject(const char* k, ObjType t) {
	if (k) {
		printKey(k);	
	}
	else {
		printf("%s%-*.*s", open_, indent_, indent_, " ");
	}
	printf("%c\n", t == type_object ? '{' : '[');
	indent_ += 2;
	open_ = "";
}
void JsonOutput::endObject(ObjType t) {
	assert(indent_ > 0);
	indent_ -= 2;
	printf("\n%-*.*s%c", indent_, indent_, " ", t == type_object ? '}' : ']');
	open_ = ",\n";
}

void JsonOutput::reportState(int state, bool enter, double) {
	if (indent_ == 0) {
		open_ = "";
		JsonOutput::startObject();
	}
	if (state == ClaspFacade::state_start && enter) {
		printKeyValue("Solver", solver().c_str());
		printKeyValue("Input", input().c_str());
	}
}

void JsonOutput::startModel() {
	if (!hasWitness_) {
		JsonOutput::startObject("Witnesses", type_array);
		hasWitness_ = true;
	}
	if (hasModel_) {
		endObject();
		hasModel_ = false;
	}
	JsonOutput::startObject();
	hasModel_ = true;
}
	
void JsonOutput::printModel(const Model& m, const SymbolTable& index, const Enumerator&) {
	startModel();
	JsonOutput::startObject("Value", type_array);
	const char* sep = "";
	printf("%-*s", indent_, " ");
	if (index.type() == SymbolTable::map_indirect) {
		for (SymbolTable::const_iterator it = index.begin(); it != index.end(); ++it) {
			if (m.value(it->second.lit.var()) == trueValue(it->second.lit) && !it->second.name.empty()) {
				printString(it->second.name.c_str(), sep);
				sep = ", ";
			}	
		}
	}
	else {
		for (Var v = 1; v < index.size(); ++v) {
			printf("%s%d", sep, (m.value(v) == value_false ? -static_cast<int>(v) : static_cast<int>(v)));
			sep = ", ";
		}
	}
	endObject(type_array);
}

void JsonOutput::printConsequences(const SymbolTable& index, const Enumerator&, const char* cbType) {
	startModel();
	JsonOutput::startObject(cbType, type_array);
	const char* sep = "";
	printf("%-*s", indent_, " ");
	for (SymbolTable::const_iterator it = index.begin(); it != index.end(); ++it) {
		if (it->second.lit.watched()) {
			printString(it->second.name.c_str(), sep);
			sep = ", ";
		}
	}
	endObject(type_array);
}

void JsonOutput::printOptimize(const SharedMinimizeData& m) { 
	JsonOutput::startObject("Opt", type_array);
	const SharedMinimizeData::SumVec& opt = m.optimum()->opt;
	printf("%-*s", indent_, " ");
	const char* sep = "";
	for (uint32 i = 0, end = m.numRules(); i != end; ++i) {
		printf("%s%" PRId64, sep, opt[i]);
		sep = ", ";
	}
	endObject(type_array);
	if (hasModel_) {
		endObject();
		hasModel_ = false;		
	}
}
void JsonOutput::printSolution(RunSummary::Result r) {
	if (hasModel_) {
		hasModel_ = false;
		endObject();
	}
	if (hasWitness_) {
		hasWitness_ = false;
		endObject(type_array);
	}
	printKeyValue("Result", result[r]);
}
void JsonOutput::printSummary(const RunSummary& sol) {
	const Enumerator& en = sol.enumerator;
	int sig = sol.termSig();
	if      (sig == SIGALRM) { printKeyValue("TIME LIMIT", uint32(1));  }
	else if (sig)            { printKeyValue("INTERRUPTED", uint32(1)); }	
	JsonOutput::startObject("Models");
	printKeyValue("Number", sol.models());
	printKeyValue("More", sol.complete() ? "no" : "yes");
	if (en.enumerated) {
		if (sol.models() != en.enumerated) {
			printKeyValue("Enumerated", en.enumerated);
		}
		if (sol.consequences) {
			printKeyValue(sol.consequences, sol.complete() ? "yes":"unknown");
		}
		if (en.minimize()) {
			printKeyValue("Optimum", sol.complete()?"yes":"unknown");
			if (en.optimize()) {
				printOptimize(*en.minimize());
			}
		}
	}
	endObject();
	JsonOutput::startObject("Time");
	printKeyValue("Total", sol.totalTime);
	printKeyValue("Solve", sol.solveTime);
	printKeyValue("Model", sol.modelTime);
	printKeyValue("Unsat", sol.unsatTime);
	printKeyValue("CPU", sol.cpuTime);
	JsonOutput::endObject(); // Time
	if (sol.ctx.concurrency() > 1) {
		printKeyValue("Threads", sol.ctx.concurrency());
		printKeyValue("Winner",  sol.ctx.winner());
	}
}

void JsonOutput::printMainStats(const SolveStats& st, bool accu) {
	JsonOutput::startObject("Core");
	printKeyValue("Choices", st.choices);
	printKeyValue("Conflicts", st.conflicts);
	printKeyValue("Backtracks", st.backtracks());
	printKeyValue("Backjumps", st.backjumps());
	printKeyValue("Restarts", st.restarts);
	printKeyValue("RestartAvg", st.avgRestart());
	printKeyValue("RestartLast", st.cflLast);
	JsonOutput::endObject(); // Core
	if (!st.extra) { return; }
	const ExtendedStats& stx = *st.extra;
	JsonOutput::startObject("More");
	if (!accu) {
		printKeyValue("CPU Time", stx.cpuTime);
		printKeyValue("Models",   stx.models);
	}
	if (stx.numTests) {
		JsonOutput::startObject("StabTests");
		printKeyValue("Sum", stx.numTests);
		printKeyValue("Full", stx.numTests - stx.numPartial);
		printKeyValue("Partial", stx.numPartial);
		JsonOutput::endObject();
	}
	if (stx.models) {
		printKeyValue("AvgModel", stx.avgModel());
	}
	printKeyValue("Splits", stx.splits);
	printKeyValue("Problems", stx.gps);
	printKeyValue("AvgGPLength", stx.avgGp());
	JsonOutput::startObject("Lemma");
	printKeyValue("Sum", stx.sumLemmas());
	printKeyValue("Deleted" , stx.deleted);
	JsonOutput::startObject("Type", type_array);
	const char* names[] = {"Short", "Conflict", "Loop", "Other"};
	for (int i = Constraint_t::static_constraint; i <= Constraint_t::learnt_other; ++i) {
		JsonOutput::startObject();
		printKeyValue("Type", names[i]);
		if (i == 0) {
			printKeyValue("Sum", stx.binary+stx.ternary);
			printKeyValue("Ratio", percent(stx.binary+stx.ternary, stx.sumLemmas()));
			printKeyValue("Binary", stx.binary);
			printKeyValue("Ternary", stx.ternary);
		}
		else {
			printKeyValue("Sum", stx.num(ConstraintType(i)));
			printKeyValue("AvgLen", stx.avgLen(ConstraintType(i)));
		}
		JsonOutput::endObject();
	}
	JsonOutput::endObject(type_array);
	JsonOutput::endObject(); // Lemma
	if (stx.distributed || stx.integrated) {
		JsonOutput::startObject("Distribution");
		printKeyValue("Distributed", stx.distributed);
		printKeyValue("Ratio", stx.distRatio());
		printKeyValue("AvgLbd", stx.avgDistLbd());
		JsonOutput::endObject();
		JsonOutput::startObject("Integration");
		printKeyValue("Integrated", stx.integrated);
		printKeyValue("Units", stx.intImps);
		printKeyValue("AvgJump", stx.avgIntJump());
		if (accu) { printKeyValue("Ratio", stx.intRatio()); }
		JsonOutput::endObject();
	}
	JsonOutput::endObject(); // More
}
void JsonOutput::printProblemStats(const ProblemStats& p, const PreproStats* lp) {
	JsonOutput::startObject("Problem");
	if (lp) {
		JsonOutput::startObject("LP");
		printKeyValue("Atoms", lp->atoms);
		if (lp->auxAtoms) { printKeyValue("AuxAtoms", lp->auxAtoms); }
		JsonOutput::startObject("Rules");
		printKeyValue("Sum", lp->sumRules());
		char buf[10];
		PreproStats::RPair r;
		for (RuleType i = BASICRULE; i != ENDRULE; ++i) {
			r = lp->rules(i);
			if (r.first) {
				sprintf(buf, "R%u", i);
				printKeyValue(buf, r.first);
			}
		}
		r = lp->rules(BASICRULE);
		if (lp->tr()) {
			printKeyValue("Created", r.second - r.first);
			JsonOutput::startObject("Translated");
			for (RuleType i = BASICRULE; ++i != ENDRULE;) {
				r = lp->rules(i);
				if (r.first > 0) {
					sprintf(buf, "R%u", i);
					printKeyValue(buf, r.first-r.second);
				}
			}
			JsonOutput::endObject();
		}
		JsonOutput::endObject(); // Rules
		printKeyValue("Bodies", lp->bodies);
		if      (lp->sccs == 0)              { printKeyValue("Tight", "yes"); }
		else if (lp->sccs == PrgNode::noScc) { printKeyValue("Tight", "N/A"); }
		else                                {
			printKeyValue("Tight", "no");
			printKeyValue("SCCs", lp->sccs);
			printKeyValue("NonHcfs", lp->nonHcfs);
			printKeyValue("UfsNodes", lp->ufsNodes);
			printKeyValue("NonHcfGammas", lp->gammas);
		}
		JsonOutput::startObject("Equivalences");
		printKeyValue("Sum", lp->sumEqs());
		printKeyValue("Atom", lp->numEqs(Var_t::atom_var));
		printKeyValue("Body", lp->numEqs(Var_t::body_var));
		printKeyValue("Other", lp->numEqs(Var_t::atom_body_var));
		JsonOutput::endObject();
		JsonOutput::endObject(); // LP
	}
	printKeyValue("Variables", p.vars);
	printKeyValue("Eliminated", p.vars_eliminated);
	printKeyValue("Frozen", p.vars_frozen);
	JsonOutput::startObject("Constraints");
	uint32 sum = p.constraints + p.constraints_binary + p.constraints_ternary;
	printKeyValue("Sum", sum);
	printKeyValue("Binary", p.constraints_binary);
	printKeyValue("Ternary", p.constraints_ternary);
	JsonOutput::endObject(); // Constraints
	JsonOutput::endObject(); // PS
}

void JsonOutput::printJumpStats(const JumpStats& st, bool) {
	JsonOutput::startObject("Jumps");
	printKeyValue("Sum", st.jumps);
	printKeyValue("Max", st.maxJump);
	printKeyValue("MaxExec", st.maxJumpEx);
	printKeyValue("Avg", st.avgJump());
	printKeyValue("AvgExec", st.avgJumpEx());
	printKeyValue("Levels", st.jumpSum);
	printKeyValue("LevelsExec", st.jumped());
	JsonOutput::startObject("Bounded");
	printKeyValue("Sum", st.bJumps);
	printKeyValue("Max", st.maxBound);
	printKeyValue("Avg", st.avgBound());
	printKeyValue("Levels", st.boundSum);
	JsonOutput::endObject();
	JsonOutput::endObject();
}

void JsonOutput::printFooter() { 
	while (indent_) { JsonOutput::endObject(); }
	fflush(stdout); 
}

}

using namespace Clasp;
#if WITH_CLASPRE
#include <program_opts/program_options.h>
#include <program_opts/typed_value.h>
#include <sstream>
namespace Claspre {
void Options::initOptions(ProgramOptions::OptionContext& root) {
	using namespace ProgramOptions;
	OptionGroup pre("Claspre Options");
	pre.addOptions()
		("list-features"   , flag(listFeatures),"Print feature names (in --features=C1 format)")
		("features!"   , storeTo(features, &Options::mapFormat),
			"Print features in selected format\n"
			"      %A: {V|C1|C2|C3}\n"
			"        V : Print features in human-readable format\n"
			"        C1: Print in compact format; iterated features in separate lines\n"
			"        C2: Print in compact format; iterated features all in one line\n"
			"        C3: Print in C2 format but only if search state is unknown on exit")
	;
	root.add(pre);
}
bool Options::validateOptions(const ProgramOptions::ParsedOptions& vm) { 
	hasLimit = vm.count("search-limit") != 0;
	return true; 
}

void Options::printFeatures() const {
	printf("maxLearnt,maxConflicts,Constraints,LearntConstraints,FreeVars,Vars/FreeVars,FreeVars/Constraints,Vars/Constraints,maxLearnt/Constraints\n");
	printf(
		"Completed,,Atoms,_Original,_Auxiliary,Rules,_Basic,_Constraint,_Choice,_Weight,NormalRules/ExtRules"
		",Bodies,Equivalences,_Atom=Atom,_Body=Body,_Other,Tight,_SCCs,_Nodes,Variables,_Eliminated,Constraints,_Binary,_Ternary,_Other"
		",Models,Choices,Conflicts,Restarts,Constraints deleted,Backtracks,Backjumps,_Bounded,Skippable Levels,Levels skipped,_%%,Max Jump Length"
		",_Executed,Max Bound Length,Average Jump Length,_Executed,Average Bound Length,Average Model Length,Lemmas,_Binary,_Ternary,_Other,Conflicts,_Average Length,Loops,_Average Length\n"
	);
}

bool Options::mapFormat(const std::string& s, int& format) {
	if (s.size() == 1 && s[0] == 'V' || s[0] == 'v') {
		format = features_verbose; 
		return true;
	}
	if (s.size() == 2 && s[0] == 'C' || s[0] == 'c') {
		if (s[1] == '1') { format = features_compact_1; return true; }
		if (s[1] == '2') { format = features_compact_2; return true; }
		if (s[1] == '3') { format = features_compact_3; return true; }
	}
	return s == "no" && (format = features_no, true);
}

/////////////////////////////////////////////////////////////////////////////////////////
// ClaspreOutput
/////////////////////////////////////////////////////////////////////////////////////////
class ClaspreOutput : public DefaultOutput {
public:
	ClaspreOutput(Options::FeatureFormat f, int v, const std::pair<int,int>& q, DefaultOutput::Format outf);
	void initSolve(const Solver& s, ProgramBuilder* api);
	void reportStats(const RunSummary& sol, const SolveStats& accu, bool more);
	void reportProgress(const PreprocessEvent&) {}
	void reportProgress(const SolveEvent& ev);
	void reportState(int state, bool enter, double time) {
		if (format_ ==  Options::features_verbose) { DefaultOutput::reportState(state, enter, time); }
	}
private:
	void printSolution(RunSummary::Result r) { if (allowResult()) { DefaultOutput::printSolution(r); } }
	void printSummary(const RunSummary& sol) { if (allowResult()) { DefaultOutput::printSummary(sol); } }
	bool allowResult() const                 { return format_ != Options::features_compact_1 && format_ != Options::features_compact_2; }
	std::string iterationBuffer_;
	Options::FeatureFormat format_;
	uint32 starts_;
};

ClaspreOutput::ClaspreOutput(Options::FeatureFormat f, int v, const std::pair<int,int>& q, DefaultOutput::Format outf) 
	: DefaultOutput(v, q, outf), format_(f), starts_(0) {
}

void ClaspreOutput::initSolve(const Solver& s, ProgramBuilder* api) {
	DefaultOutput::initSolve(s, api);
	starts_          = 0;
	iterationBuffer_ = "";
	if (format_ != Options::features_verbose) {
		int v = (format_ == Options::features_compact_3);
		setVerbosity(v);
	}
}

void ClaspreOutput::reportProgress(const SolveEvent& e) {
	if (e.type != SolveEvent_t::progress_path || static_cast<const SolvePathEvent&>(e).evType != SolvePathEvent::event_restart) { return; }
	const SolvePathEvent& ev = static_cast<const SolvePathEvent&>(e);
	std::stringstream temp;
	const Solver& s = *ev.solver;
	uint64 maxC     = ev.cLimit;
	uint32 maxL     = ev.lLimit;
	if (format_ == Options::features_verbose) {
		printf("\n[Iteration %u]\n", starts_);
		printf("%-22s: %u\n", "maxLearnt", maxL);
		printf("%-22s: %" PRIu64"\n", "maxConflicts", maxC);
		printf("%-22s: %u\n", "Constraints", s.numConstraints());
		printf("%-22s: %u\n", "LearntConstraints", s.numLearntConstraints());
		printf("%-22s: %u\n", "FreeVars", s.numFreeVars());
		printf("%-22s: %.3f\n", "Vars/FreeVars", ((double)s.numVars())/std::max(s.numFreeVars(),uint32(1)));
		printf("%-22s: %.3f\n", "FreeVars/Constraints", ((double)s.numFreeVars())/s.numConstraints());
		printf("%-22s: %.3f\n", "Vars/Constraints", ((double)s.numVars())/s.numConstraints());
		printf("%-22s: %.3f\n", "maxLearnt/Constraints", ((double)maxL)/s.numConstraints());
		if (s.stats.jumps) {
			printf("%-22s: %.3f\n", "Average Jump Length", s.stats.jumps->avgJump());
		}
		printf("=================================\n\n");
	}
	else {
		uint32 numC = std::max(s.numConstraints(), uint32(1));
		temp.precision(3);
		temp << std::fixed << maxL << "," << maxC << "," << s.numConstraints() << "," << s.numLearntConstraints() << "," << s.numFreeVars() << ","
			   << (static_cast<double>(s.numVars())/std::max(s.numFreeVars(), uint32(1))) << ","
				 << (static_cast<double>(s.numFreeVars())/numC) << ","
				 << (static_cast<double>(s.numVars())/numC) << ","
				 << (static_cast<double>(maxL)/numC);
		if (format_ == Options::features_compact_1) {
			printf("%s\n", temp.str().c_str());
		}
		else {
			if (!iterationBuffer_.empty()) iterationBuffer_ += ",";
			iterationBuffer_ += temp.str();
		}
	}
	++starts_;
}

void ClaspreOutput::reportStats(const RunSummary& sol, const SolveStats& accu, bool more) {
	bool hasSolution = sol.complete() || sol.models() > 0;
	if (format_ == Options::features_verbose) {
		DefaultOutput::reportStats(sol, accu, more);
	}
	else {
		if (starts_ == 0) {
			reportProgress(SolvePathEvent(*sol.ctx.master(), SolvePathEvent::event_restart, 0, 0));
		}
		if (!iterationBuffer_.empty()) {
			printf("\n%s\n", iterationBuffer_.c_str());
		}
		const PreproStats& ps = lpStats() ? *lpStats() : PreproStats();
		uint32 auxAtoms = ps.auxAtoms;
		uint32 orgAtoms = ps.atoms-auxAtoms;
		uint32 extRules = ps.rules(CONSTRAINTRULE).second + ps.rules(WEIGHTRULE).second;
		if (!extRules) extRules = 1;
		printf("%s,%u,%u,%u,%u,%u,%u,%u,%u,%.3f", (hasSolution ? "Yes":"No"), ps.atoms, orgAtoms, auxAtoms, ps.sumRules(), ps.rules(BASICRULE).second
			, ps.rules(CONSTRAINTRULE).second
			, ps.rules(CHOICERULE).second
			, ps.rules(WEIGHTRULE).second
			, ps.rules(BASICRULE).second / static_cast<double>(extRules));
		uint32 tight = ps.sccs == 0 || ps.sccs == PrgNode::noScc;
		uint32 sccs  = ps.sccs != PrgNode::noScc ? ps.sccs : 0;
		printf(",%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%.3f,%.3f,%.3f", ps.bodies, ps.sumEqs(), ps.numEqs(Var_t::atom_var), ps.numEqs(Var_t::body_var), ps.numEqs(Var_t::atom_body_var)
			, tight, sccs, ps.ufsNodes, sol.ctx.stats().vars, sol.ctx.stats().vars_eliminated
			, sol.ctx.stats().constraints
			, percent(sol.ctx.stats().constraints_binary, sol.ctx.stats().constraints)
			, percent(sol.ctx.stats().constraints_ternary, sol.ctx.stats().constraints)
			, percent(sol.ctx.stats().constraints - (sol.ctx.stats().constraints_binary+sol.ctx.stats().constraints_ternary), sol.ctx.stats().constraints));
		
		std::stringstream temp;
		const SolveStats& st     = accu;
		const JumpStats& js      = st.jumps ? *st.jumps : JumpStats();
		const ExtendedStats& stx = st.extra ? *st.extra : ExtendedStats();  
		uint64 learntSum         = stx.sumLemmas();
		temp.precision(3);
		temp << std::fixed << "," << stx.models << "," << st.choices << "," << st.conflicts << "," << st.restarts << "," << stx.deleted << "," 
				 << st.backtracks() << "," << st.backjumps() << "," << js.bJumps << ","
				 << js.jumpSum << "," << js.jumped() << "," << js.jumpedRatio()*100.0 << ","
				 << js.maxJump << "," << js.maxJumpEx << "," << js.maxBound << "," << js.avgJump() << "," << js.avgJumpEx() << ","
				 << js.avgBound() << "," << stx.avgModel() << ","
				 << learntSum << "," << percent(stx.binary, learntSum) << "," << percent(stx.ternary, learntSum) << "," 
				 << percent(learntSum-stx.binary-stx.ternary, learntSum) << ","
				 << stx.num(Constraint_t::learnt_conflict) << "," << stx.avgLen(Constraint_t::learnt_conflict) << ","
				 << stx.num(Constraint_t::learnt_loop) << "," << stx.avgLen(Constraint_t::learnt_loop);
		printf("%s\n\n", temp.str().c_str());
	}
}
OutputFormat* Options::createOutput(uint32 v, DefaultOutput::PrintPair q, DefaultOutput::Format f) { 
	if (features != Options::features_verbose) {
		v = 0;
		if (features != Options::features_compact_3) {
			q.first = q.second = DefaultOutput::print_no;
		}
	}
	return new ClaspreOutput(static_cast<Options::FeatureFormat>(features), v, q, f);
}


} // namespace Claspre
#else
namespace Claspre {
void Options::initOptions(ProgramOptions::OptionContext&) {}
bool Options::validateOptions(const ProgramOptions::ParsedOptions&) { return true; }
void Options::printFeatures() const {}
OutputFormat* Options::createOutput(uint32, DefaultOutput::PrintPair, DefaultOutput::Format) { return 0; }
}
#endif
