// 
// Copyright (c) 2006-2012, Benjamin Kaufmann
// 
// This file is part of Clasp. See http://www.cs.uni-potsdam.de/clasp/ 
// 
// Clasp is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// Clasp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Clasp; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//
#ifndef CLASP_CLASP_OPTIONS_H_INCLUDED
#define CLASP_CLASP_OPTIONS_H_INCLUDED

#ifdef _MSC_VER
#pragma warning (disable : 4200) // nonstandard extension used : zero-sized array
#pragma once
#endif

#include <string>
#include <utility>
#include <program_opts/app_options.h>
#include <clasp/clasp_facade.h>
#include <clasp/solver.h>
#include <iosfwd>

namespace ProgramOptions {
struct StringSlice;
// Specialized function for mapping unsigned integers
// Parses numbers >= 0, -1, and the string umax
StringSlice parseValue(const StringSlice& in, uint32& x, int extra);
}
namespace Clasp {

/////////////////////////////////////////////////////////////////////////////////////////
// Option groups - Mapping between command-line options and libclasp objects
/////////////////////////////////////////////////////////////////////////////////////////
// Function for mapping positional options
bool parsePositional(const std::string& s, std::string& out);
struct StringToEnum {
	const char* str; // string value
	int         ev;  // corresponding enum value
};
typedef StringToEnum EnumMap;

// Mode (enumeration/optimization), solving (algo-type/threads), and ASP options for generator.
struct ModeOptions {
	explicit ModeOptions(GlobalOptions* opts = 0) : config(opts) {}
	static bool mapOptVal(ModeOptions*, const std::string&, const std::string&);
	static bool parseSolveLimit(const std::string& s, SolveLimits& limit);
	static bool mapSolveOpts(ModeOptions*, const std::string& k, const std::string& v);
	void initOptions(ProgramOptions::OptionContext& root);
	void addSolveOptions(ProgramOptions::OptionGroup& root);
	bool validateOptions(const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& parsed, ProgramOptions::Messages&);
	GlobalOptions* config;
	static const EnumMap enumModes[];
	static const EnumMap extRules[];
};

// Groups "Clasp - Search Options" and "Clasp - Lookback Options"
// Options of these groups are mapped to ClaspConfig::solve 
// and ClaspConfig::solver
struct SearchOptions {
	struct SolverConfig {
		SolverConfig(SolverStrategies& st, SolveParams& sx) : solver(&st), search(&sx) {}
		SolverStrategies* solver;
		SolveParams*      search;
	};
	explicit SearchOptions(const SolverConfig& l);
	void initOptions(ProgramOptions::OptionContext& root);
	void initOptions(const ProgramOptions::OptionContext& root, ProgramOptions::OptionContext& local, const SolverConfig& x);
	bool validateOptions(const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& parsed, ProgramOptions::Messages&);
	// value parsing 
	static bool parseSchedule(const std::string& s, ScheduleStrategy& sched, bool allowNo);
	// value mapping
	static bool mapSolverOpts(SearchOptions*, const std::string& opt, const std::string& v);
	static bool mapSearchOpts(SearchOptions*, const std::string& opt, const std::string& v);
	static bool mapRestart(SearchOptions*   , const std::string& opt, const std::string& v);
	static bool mapReduceOpts(SearchOptions*, const std::string& opt, const std::string& v);
	
	SolverConfig config;
	static const EnumMap heuTypes[];
	static const EnumMap lookTypes[];
	static const EnumMap loopTypes[];
	static const EnumMap delAlgos[];
};
	
extern const char* portfolio_g;
extern const char* defConfigs_g;
struct OptionConfig {
	explicit OptionConfig(const char* raw) { initFromRaw(raw); }
	void initFromRaw(const char* r);
	std::string name;
	std::string cmdLine;
};
// Combines all groups and drives initialization/validation 
// of command-line options.
class ClaspOptions {
public:
	ClaspOptions() : genTemplate(false), clasp(0), active(0) {}
	std::string  portfolio;
	std::string  testerOpts;
	bool         genTemplate;
	bool         satPreParsed;
	void         initOptions(ProgramOptions::OptionContext& root, ClaspConfig& c);
	bool         validateOptions(const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& parsed, ProgramOptions::Messages&);
	void         applyDefaults(Input::Format f);
	const char*  getInputDefaults(Input::Format f) const;
	static bool  mapDefaultConfig(ClaspOptions*, const std::string&, const std::string&);
	static bool  mapCtxOpts(ClaspOptions*, const std::string&, const std::string&);
private:
	static const char*  loadPortfolio(const std::string& file, std::string& mem);
	bool applyDefaultConfig(const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& parsed, ProgramOptions::Messages&);
	bool applySearchConfig(const ProgramOptions::OptionContext& ctx, const OptionConfig& c, const ProgramOptions::ParsedOptions&, ProgramOptions::Messages&);
	bool populateThreadConfigs(uint32 num, const ProgramOptions::OptionContext& root, const ProgramOptions::ParsedOptions& parsed, ProgramOptions::Messages&);
	bool applyTesterConfig(ProgramOptions::Messages&);
	void initCommandOptions(ProgramOptions::OptionContext& root);
	void initSearchOptions(ProgramOptions::OptionContext& root);
	void addMtCtxOptions(ProgramOptions::OptionGroup& root);
	void removeConfig(OptionConfig& cfg, const char* opt) const;
	ClaspConfig*                   clasp;
	UserConfiguration*             active;
	const char*                    defConfig;
	std::auto_ptr<ModeOptions>     mode;
	std::auto_ptr<SearchOptions>   search;
};
}
#endif

